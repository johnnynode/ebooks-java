public class Class10{
  int  a;
  void setA(int a){
    this.a=a;
  }
  int getA(){
    return a;  	
  }
  public static void main(String[] args){
     Class10 ob= new Class10();
     ob.setA(1000);
     System.out.println(ob.a);
     System.out.println(ob.getA());
  } 
}