public class Textual{
  public static void main(String[] args){
    char a, b, c;
    a='A';
    b='��';
    c='��';
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
  }
}
