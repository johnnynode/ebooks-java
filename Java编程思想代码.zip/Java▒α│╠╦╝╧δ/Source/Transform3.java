import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
public class Transform3 extends Frame implements ActionListener{
  double scale=1;
  Button flipX=new Button("x�� ����");
  Button flipY=new Button("y�� ����");
  Button scaleUp=new Button("2�� Ȯ��");
  Button scaleDown=new Button("1/2�� ���");
  Graphics2D g2;
  public Transform3(String title){
    super(title);
    setLayout(new FlowLayout());
    add(flipX);
    add(flipY);
    add(scaleUp);
    add(scaleDown);
    flipX.addActionListener(this);
    flipY.addActionListener(this);
    scaleUp.addActionListener(this);
    scaleDown.addActionListener(this);
  }
  public void actionPerformed(ActionEvent ae){
    if(ae.getSource()==flipX)
      g2.scale(1, -1); 
    else if(ae.getSource()==flipY)
      g2.scale(-1, 1);
    else if(ae.getSource()==scaleUp)
      g2.scale(2, 2);
    else if(ae.getSource()==scaleDown)
      g2.scale(0.5, 0.5);
    repaint();
  }
  public void paint(Graphics g){
    if(g2==null){
      g2=(Graphics2D)getGraphics();
      g2.translate(150,150);
    } 
    
    g2.draw(new Line2D.Float(-100, 0, 100, 0));
    g2.draw(new Line2D.Float(0, -100, 0, 100));
    g2.fill(new Ellipse2D.Float(50, 50, 20, 20));
  }  
  public static void main(String[] args){
    Frame f=new Transform3("�����ϸ�");
    f.setSize(300, 300);
    f.setVisible(true);
  }
}
