class Inher6_1{
  void hello(){
  	System.out.println("���̿�");
  }
}
public class Inher6 extends Inher6_1{
  void hello(){
  	super.hello();
  	System.out.println("�氡��");
  }
  public static void main(String[] args){
    Inher6 ob=new Inher6();
    ob.hello();
  }
}