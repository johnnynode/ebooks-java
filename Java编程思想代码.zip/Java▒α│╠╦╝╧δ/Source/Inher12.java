public class Inher12{
  public static void main(String[] args){
    Object[] ob = new Object[3]; 
    ob[0] = new String("abc");
    ob[1] = new Boolean(true);
    ob[2] = new Integer(5);
    
    for(int i=0;i<ob.length;i++)
       System.out.println(ob[i]);
  }
}