import java.awt.*;
import java.io.*;
public class FileDialog1 extends Frame{
  FileDialog fopen;
  TextArea ta;
  public FileDialog1(String title){
  	super(title);
  	ta=new TextArea();
  	add(ta);
  	setSize(300,300);
  }
  public String showLoad(){
  	fopen=new FileDialog(this,"���� ����",FileDialog.LOAD);
    fopen.setVisible(true);
    String fileName=fopen.getFile();
    String fileDir=fopen.getDirectory();
    if(fileName==null){
      return null;
    }
    return fileDir+"\\"+fileName;
  }
  public void loadFile(String fileName) throws IOException{
    BufferedReader br=new BufferedReader(new FileReader(fileName));
    String aline;
    while((aline=br.readLine())!=null)
        ta.append(aline+'\n');  
    br.close();
  }
  public void saveFile(){}
  public static void main(String[] args){
    FileDialog1 fdlg=new FileDialog1("���� �ҷ�����");
    String fileName;
    if((fileName=fdlg.showLoad())==null)
      System.out.println("������ �������� �ʾҽ��ϴ�.");
    else{
      try{
        fdlg.loadFile(fileName);
      }catch(IOException ie){
        System.out.println(ie);
      }
    }  
    fdlg.setVisible(true);
  }
}
