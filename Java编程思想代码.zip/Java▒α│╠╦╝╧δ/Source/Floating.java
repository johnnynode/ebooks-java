public class Floating{
  public static void main(String[] args){
    float   f=1.23f;
    double  d=1.23;
    System.out.println(f);
    System.out.println(d);
  }
}