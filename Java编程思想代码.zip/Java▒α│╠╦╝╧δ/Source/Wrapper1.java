public class Wrapper1{
  public static void main(String[] args){
    int a=7;
    String b="123";
    Integer w1=new Integer(a);
    Integer w2=new Integer(b);
    System.out.println(w1);
    System.out.println(w2);
  }
}




















