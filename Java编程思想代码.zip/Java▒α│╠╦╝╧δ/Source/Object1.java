public class Object1{
  int a,b;
  Object1(int a, int b){
  	this.a=a;
  	this.b=b;
  	System.out.println("��ü�� ����");
  }	
  public static void main(String[] args){
    Object1 ob1, ob2;
    ob1=new Object1(10, 20);
    ob2=new Object1(20, 30);
    ob1=ob2;
  }
}