import java.io.*;
public class File14{
  public static void main(String[] args) throws Exception{
    FileReader fr=new FileReader("c:\\autoexec.bat");
    BufferedReader br=new BufferedReader(fr);
    String s;
    while((s=br.readLine())!=null)
      System.out.println(s);
    br.close();
  }
}
