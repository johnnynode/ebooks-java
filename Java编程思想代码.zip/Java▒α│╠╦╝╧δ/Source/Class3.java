public class Class3{
  double f(int x){
  	return 2.5+x;
  }  
  public static void main(String[] args){
     Class3 aaa=new Class3();
     double y=aaa.f(3);
     System.out.println(y);
     System.out.println(aaa.f(2)); 	
  }
}