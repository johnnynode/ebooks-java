public class Array4{
  public static void main(String[] args){
  	String[] s=new String[3];
    s[0]=new String("�ȳ�");
    s[1]=new String("hello");
    s[2]=new String("�氡");
    for(int i=0;i<s.length;i++)
      System.out.println(s[i]);
  }
}