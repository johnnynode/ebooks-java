class Inher3_1{
  int a;
  Inher3_1(){
  	a=0;
  }
  Inher3_1(int a){
  	this.a=a;
  }
}
public class Inher3 extends Inher3_1{
  int b;
  Inher3(int a, int b){
  	super(a);
    this.b=b;
  }
  public static void main(String[] args){
     Inher3 ob=new Inher3(10, 20);
     System.out.println(ob.a+" "+ob.b);
  }
}