import java.awt.*;
public class TextField1{
  public static void main(String[] args){
    Frame frame=new Frame("�α��� ��ȭ����");
    TextField id=new TextField(10);
    TextField pw=new TextField(10);
    Button login=new Button("�α���");
    Button cancel=new Button("��  ��");
    pw.setEchoChar('*');
    frame.setLayout(new GridLayout(3,2));
    frame.add(new Label("�� �� ��:", Label.CENTER));
    frame.add(id);
    frame.add(new Label("��й�ȣ:", Label.CENTER));
    frame.add(pw);
    frame.add(login);
    frame.add(cancel);
    frame.pack();
    frame.setVisible(true);
  }	
}