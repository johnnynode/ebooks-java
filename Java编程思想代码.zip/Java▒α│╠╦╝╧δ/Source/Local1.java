public class Local1{
  int a=10;
  void f(){
  	class Inner{
      int c=20;
  	  void hi(){
  	  	System.out.println(a);
  	  	System.out.println(c);
  	  }	
  	}
  	Inner in=new Inner();
  	in.hi();
  }
  public static void main(String[] args){
     Local1 local=new Local1();
     local.f();
  }
}
