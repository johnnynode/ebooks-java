import java.awt.*;
public class ScrollPane2{
  public static void main(String[] args) throws Exception{
    Frame f=new Frame("ScrollPane");
    ScrollPane sp=new ScrollPane(0);
    Panel p=new Panel();
    p.setLayout(new GridLayout(0,1));
    sp.setBounds(10,30,180,160);
    f.setLayout(null);
    f.setSize(200,200);
    for(int i=1;i<=100;i++){
      p.add(new Label(i+"��° ���̺�"));
    }
    sp.add(p);
    f.add(sp);
    f.setVisible(true);
    Adjustable adj=sp.getVAdjustable();
    while(true){
      adj.setValue(adj.getValue()+1);	
      Thread.sleep(100);	
    }
  }
}