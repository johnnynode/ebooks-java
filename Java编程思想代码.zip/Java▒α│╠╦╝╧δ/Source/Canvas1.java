import java.awt.*;
import java.util.Random;
public class Canvas1 extends Canvas{
    public void paint(Graphics g){
      Random rnd=new Random();
      for(int i=1;i<=100;i++){
        g.setColor(new Color(rnd.nextInt(256),rnd.nextInt(256),
                             rnd.nextInt(256)));
        g.drawLine(rnd.nextInt(200),rnd.nextInt(200),
                   rnd.nextInt(200),rnd.nextInt(200));
      }
    }
    public static void main(String[] args){
     Frame frame=new Frame("Canvas");
     Canvas1 c=new Canvas1();
     frame.add(c);
     frame.setSize(200,200);
     frame.setVisible(true);
  }
}