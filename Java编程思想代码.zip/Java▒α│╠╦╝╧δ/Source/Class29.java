public class Class29{
  int a;
  public Class29(int a){
  	this.a=a;
  }
  public static void main(String[] args){
    Class29 ob=new Class29();
    System.out.println(ob.a);
  }
}