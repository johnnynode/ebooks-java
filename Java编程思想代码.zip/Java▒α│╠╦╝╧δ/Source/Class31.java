public class Class31{
   int a=10;
   static int b=20;
  public static void main(String[] args){
    Class31 ob=new Class31();
    System.out.println(ob.a);
    System.out.println(Class31.b);
  }
}