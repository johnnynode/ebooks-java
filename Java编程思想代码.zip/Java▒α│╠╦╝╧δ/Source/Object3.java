public class Object3{
  Object3(){
  	System.out.println("��ü�� ����");
  }
  void hi(){
  	System.out.println("�ȳ�~~~");
  }
  public static void main(String[] args){
    Object3 ob=null;
    ob.hi();
  }
}