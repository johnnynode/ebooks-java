import java.awt.*;
public class Choice1{
  public static void main(String[] args) throws Exception{
    Frame frame=new Frame("Choice Test");
    Choice ch=new Choice();
    ch.add("�̳���");
    ch.add("���縮");
    ch.add("���޷�");
    ch.add("������");
    ch.add("������");
    ch.add("������");
    frame.setLayout(null);
    frame.setBackground(Color.BLUE);
    frame.add(ch);
    frame.setSize(100,100);
    ch.setLocation(30,40);
    frame.setVisible(true);
    for(int i=0;i<ch.getItemCount();i++){
       ch.select(i);
       Thread.sleep(1000);	
    }
  }
}