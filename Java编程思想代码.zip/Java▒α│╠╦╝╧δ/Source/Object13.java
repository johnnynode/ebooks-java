public class Object13{
  String key;
  Object13(String key){
    this.key=key;	
  }
  Object13 getObjcet(){
  	return this;
  }
  public static void main(String[] args){
    Object13 ob1=new Object13("hello");
    Object13 ob2=ob1.getObjcet();
    ob2.key="�ҷ�";
    System.out.println(ob1.key);
  }
}
