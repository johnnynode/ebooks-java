import java.util.*;
public class Arrays3{
  public static void main(String[] args){
    Sagak[] a={new Sagak(2,5),new Sagak(3,3),
               new Sagak(1,2),new Sagak(2,2)};
    Arrays.sort(a);
    for(int i=0;i<a.length;i++)
      System.out.println(a[i].getArea());
  }
}