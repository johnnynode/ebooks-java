import java.util.*;
class Sagak implements Comparable{
  private int width;
  private int height;
  Sagak(int width, int height){
  	this.width=width;
  	this.height=height;
  }
  int getArea(){
  	return width*height;
  }
  public int compareTo(Object o){
    Sagak s=(Sagak)o;
    return getArea()-s.getArea();
  }	
}
public class Arrays2{
  public static void main(String[] args){
    Sagak a=new Sagak(1,2);
    Sagak b=new Sagak(2,3);
    System.out.println(a.compareTo(b));
  }	
}