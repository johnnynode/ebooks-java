public class Wrapper2{
  public static void main(String[] args){
    int a=20;
    Integer w=new Integer(10);
    System.out.println(a+w.intValue());
    int b=Integer.parseInt("123");
    System.out.println(b);
    int c=Integer.parseInt("12",8);
    System.out.println(c);
    System.out.println(Integer.toBinaryString(-1));
  }
}
















