import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
public class Composite1 extends Frame{
  public Composite1(String title){
    super(title);
  }
  public void paint(Graphics g){
  	Graphics2D g2=(Graphics2D)g;
    g2.setPaint(Color.red);
    g2.fill(new Ellipse2D.Float(50,50, 100,100));
    g2.setPaint(Color.blue);
    for(float i=0.0f; i<=1.0f;i+=0.01f){
      g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, i));
      g2.fill(new Ellipse2D.Float(100,50,100,100));
      try{
        Thread.sleep(100);
      }catch(Exception e){}
    }
  }  
  public static void main(String[] args){
    Frame f=new Composite1("���� ȿ��");
    f.setSize(250,200);
    f.setVisible(true);
  }
}
