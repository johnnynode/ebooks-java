import java.util.*;
public class Hashtable1{
  public static void main(String[] args){
    Hashtable ht=new Hashtable();
    ht.put("001131-1234567","ȫ�浿");
    ht.put("010230-2345678","�����");
    ht.put("020931-1456007","��ö��");
    ht.put("111228-1899001","�̼���");
    
    if(ht.containsKey("020931-1456007"))
      ht.remove("020931-1456007");
    
    System.out.println("����� ����: "+ht.size());
    System.out.println("<���>");
    for(Enumeration e=ht.elements(); e.hasMoreElements(); )
      System.out.println(e.nextElement());
  }
}