public class Operator9{
  public static void main(String[] args){
  	  int a=10;
      System.out.println((a>0)&&(a=20)>10);
      System.out.println(a);
      int b=10;
      System.out.println((b<0)&&(b=20)>10);
      System.out.println(b);
   	}
}