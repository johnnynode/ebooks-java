public class Operator6{
  public static void main(String[] args){
      int a=1;
      int b=2;
      System.out.println(a==b);
      System.out.println(a>b);
      System.out.println(!(a>b));
      System.out.println(b==2);
      System.out.println(!(a!=b));
      System.out.println();
      
      System.out.println(true==false);
      System.out.println(true==(1>0));
      System.out.println(!!!!true);
   	}
}