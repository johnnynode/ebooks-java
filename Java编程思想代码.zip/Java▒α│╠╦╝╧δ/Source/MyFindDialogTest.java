import java.awt.*;
import java.awt.event.*;

class MyFindDialog extends Dialog implements ActionListener{
  private Label lFind=new Label("ã�� ���ڿ�:");
  private Label lReplace=new Label("�ٲ� ���ڿ�:");
  private TextField tFind=new TextField(10);
  private TextField tReplace=new TextField(10);
  private Button bFind=new Button("ã��");
  private Button bReplace=new Button("�ٲٱ�");
  private TextArea ta;
  public MyFindDialog(Frame owner, TextArea ta){
    super(owner,"ã��",false);
    this.ta=ta;
    setLayout(null);
    lFind.setBounds(10,30,80,20);
    lReplace.setBounds(10,70,80,20);
    tFind.setBounds(90,30,90,20);
    tReplace.setBounds(90,70,90,20);
    bFind.setBounds(190,30,80,20);
    bReplace.setBounds(190,70,80,20);
    add(lFind); add(tFind); add(bFind); add(lReplace);
    add(tReplace); add(bReplace);
    setResizable(false);
    bFind.addActionListener(this);
    bReplace.addActionListener(this);
    addWindowListener( new WindowAdapter(){
         public void windowClosing(WindowEvent e){
           MyFindDialog.this.dispose();
         }
    });
  }
  public void showFind(){
    setTitle("ã��");
    setSize(280,60);
    setVisible(true);
  }
  public void showReplace(){
    setTitle("ã�� �ٲٱ�");
    setSize(280,110);
    setVisible(true);
  }
 
  private void find(){
    String text=ta.getText();
    String str=tFind.getText();
    int end=text.length();
    int len=str.length();
    int start=ta.getSelectionEnd();
    if(start==end)start=0;
    for( ;start<=end-len;start++){
      if(text.substring(start,start+len).equals(str)){
         ta.setSelectionStart(start);
         ta.setSelectionEnd(start+len);
         return;
      }
    }
    ta.setSelectionStart(end);
    ta.setSelectionEnd(end);
  }
  private void replace(){
    String str=tReplace.getText();
    if(ta.getSelectedText().equals(tFind.getText()))
      ta.replaceRange(str,ta.getSelectionStart(),ta.getSelectionEnd());   
    else find();
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource()==bFind)
      find();
    else if(e.getSource()==bReplace)
      replace();
  }
}
public class MyFindDialogTest{
  public static void main(String[] args){
    Frame f=new Frame("MyFindDialog Test");
    TextArea ta=new TextArea();
    f.add(ta);
    MyFindDialog fDlg=new MyFindDialog(f,ta);
    f.setSize(300,300);
    f.setVisible(true);
    fDlg.showReplace();
  }
}