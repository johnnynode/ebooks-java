import java.awt.*;
import java.awt.event.*;
public class ActionEvent1 extends Frame{
  Button button;
  public ActionEvent1(String title){
  	super(title);
  	ActionListener ac=new ActionHandler();
  	button=new Button("Ȯ��");
  	button.addActionListener(ac);
  	add(button);
  }
  public static void main(String[] args){
    ActionEvent1 me=new ActionEvent1("�׼� �̺�Ʈ ó��");
    me.pack();
    me.setVisible(true);
  }
  class ActionHandler implements ActionListener{
    public void actionPerformed(ActionEvent e){
        System.out.println(e.getActionCommand());
    }
  }
}