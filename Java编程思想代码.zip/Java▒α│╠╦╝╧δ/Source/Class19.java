class Class19_A{
  private int num;
  private void hi(){
  	System.out.println("�ȳ�~~~");
  }
}
  
public class Class19{
  public static void main(String[] args){
    Class19_A ob=new Class19_A();
    ob.num=10;
    ob.hi();
  }
}