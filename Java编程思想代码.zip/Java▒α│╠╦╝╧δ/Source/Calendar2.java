import java.util.*;
public class Calendar2{
  public static void main(String[] args){
    GregorianCalendar gc= new GregorianCalendar();
    String now ="����: "
                +gc.get(Calendar.YEAR)+"��"
                +(gc.get(Calendar.MONTH)+1)+"��"
                +gc.get(Calendar.DATE)+"��";
    System.out.println(now);
    gc.add(Calendar.DATE,10000);
    String future ="�̷�: "
                +gc.get(Calendar.YEAR)+"��"
                +(gc.get(Calendar.MONTH)+1)+"��"
                +gc.get(Calendar.DATE)+"��";                
    System.out.println(future);            
  }
}