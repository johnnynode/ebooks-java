interface MyInter{
  private void method1();
  protected void method2();
}
public class Interface5 implements MyInter{
  public void method1(){
  	System.out.println("method1 override");
  }
  public void method2(){
  	System.out.println("method2 override");
  }
  public static void main(String[] args){
    Interface5 ob=new Interface5(); 
    ob.method1();
    ob.method2();
  }
}