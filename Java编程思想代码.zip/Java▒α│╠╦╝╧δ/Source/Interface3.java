interface MyInter1{
  public void method1();
}
interface MyInter2{
  public void method2();
}
class MyClass{
  public void hi(){
  	System.out.println("�ȳ�");
  }
}
public class Interface3 extends MyClass implements MyInter1, MyInter2{
  public void method1(){
  	System.out.println("method1 override");
  }
  public void method2(){
  	System.out.println("method2 override");
  }
  public static void main(String[] args){
    Interface3 ob=new Interface3(); 
    ob.method1();
    ob.method2();
    ob.hi();
  }
}