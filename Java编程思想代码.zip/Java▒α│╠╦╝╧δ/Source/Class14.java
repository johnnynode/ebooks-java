public class Class14{
  int a;
  static void setA(int b){
    a=b;
  }  
  public static void main(String[] args){
     Class14.setA(10);
  }
}