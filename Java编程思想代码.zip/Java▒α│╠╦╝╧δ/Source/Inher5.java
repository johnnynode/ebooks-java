class Inher5_1{
  int a=10;
  
}
public class Inher5 extends Inher5_1{
  int a=20;
  void f(){
  	System.out.println(super.a);
  	System.out.println(this.a);
  }
  public static void main(String[] args){
     Inher5 ob=new Inher5();
     ob.f();
  }
}