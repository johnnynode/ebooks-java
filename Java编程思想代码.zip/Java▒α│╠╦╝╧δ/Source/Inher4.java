class Inher4_1{
  private int a;
  public void setA(int a){
  	this.a=a;
  }
  int getA(){
  	return a;
  }
}
public class Inher4 extends Inher4_1{
  
  void test(){
  	// a=10;
  	setA(20);
  	System.out.println(getA());
  }
  public static void main(String[] args){
     Inher4 ob=new Inher4();
     ob.test();
  }
}