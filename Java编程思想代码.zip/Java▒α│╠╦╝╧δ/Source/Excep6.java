public class Excep6{
  static void go() throws NegativeArraySizeException{
    int[] a=new int[-1];
  }
  public static void main(String[] args){
     try{
       go();
     }catch(NegativeArraySizeException e){
       System.out.println("go�� ���ܸ� ������."); 	
     }
  } 
}