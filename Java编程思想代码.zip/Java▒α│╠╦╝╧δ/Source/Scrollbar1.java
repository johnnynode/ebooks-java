import java.awt.*;
public class Scrollbar1{
  public static void main(String[] args) throws Exception{
    Frame frame=new Frame("���� �����");
    Panel pColor=new Panel();
    Label lColor=new Label("0,0,0");
    pColor.setBackground(new Color(0,0,0));
    
    Scrollbar sRed=new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,256);
    Scrollbar sGreen=new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,256);
    Scrollbar sBlue=new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,256);
    
    frame.setLayout(new GridLayout(5,1));
    frame.add(pColor);
    frame.add(lColor);
    frame.add(sRed);
    frame.add(sGreen);
    frame.add(sBlue);
    frame.pack();
    frame.setVisible(true);
    Color col;
    int nRed, nGreen, nBlue;
    while(true){
       nRed=sRed.getValue();
       nGreen=sGreen.getValue();
       nBlue=sBlue.getValue();
       col=new Color(nRed,nGreen,nBlue);
       pColor.setBackground(col);
       lColor.setText(nRed + " , " + nGreen + " , " + nBlue);
       Thread.sleep(100);
    }
  }
}