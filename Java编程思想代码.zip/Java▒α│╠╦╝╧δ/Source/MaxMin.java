public class MaxMin{
  static int max(int[] array){
    int m=array[0];
    for(int i=1; i<array.length; i++)
      if(array[i]>m) m=array[i];
    return m;
  }
  static int min(int[] array){
    int m=array[0];
    for(int i=1; i<array.length; i++)
      if(array[i]<m) m=array[i];
    return m;
  } 
  public static void main(String[] args){
    int[] array=new int[]{20, 50, 30, 70, 90, 35, 80, 100, 95, 60};
    System.out.println("�ִ밪: " + max(array));
    System.out.println("�ּҰ�: " + min(array));
  }
}