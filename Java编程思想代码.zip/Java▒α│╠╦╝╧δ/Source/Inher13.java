public class Inher13{
  public static void main(String[] args){
    Object ob[]=new Object[3]; 
    ob[0]=new String("abc");
    ob[1]=new Boolean(true);
    ob[2]=new Integer(5);
    for(int i=0;i<ob.length;i++){
      if(ob[i] instanceof String){
        String s=(String)ob[i];       
        System.out.println(s.toUpperCase());
      }
      else if(ob[i] instanceof Boolean){
        Boolean b1=(Boolean)ob[i];  
        boolean b2=b1.booleanValue();
        System.out.println(b2 && false);
      }
    }   
  }
}