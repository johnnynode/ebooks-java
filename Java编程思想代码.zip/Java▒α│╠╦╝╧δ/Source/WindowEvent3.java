import java.awt.*;
import java.awt.event.*;
public class WindowEvent3 extends Frame{
  public WindowEvent3(){
  	setTitle("������ �ݱ� �̺�Ʈ ó��");
    WindowListener winHandler=new WindowAdapter(){
         public void windowClosing(WindowEvent e){
            CloseFrameDialog d=new CloseFrameDialog(WindowEvent3.this,"�ݱ�","�����ðڽ��ϱ�?");
            d.setSize(200,100);
            d.setVisible(true);
         }  	
    };
    addWindowListener(winHandler);
  }
  public static void main(String[] args){
    WindowEvent2 me=new WindowEvent2();
    me.setSize(200,200);
    me.setVisible(true);
  }
}