import Mypack.pack1.Class16;

public class Class17{
  public static void main(String[] args){
    Class16 ob=new Class16();
    ob.hi();
  }
}