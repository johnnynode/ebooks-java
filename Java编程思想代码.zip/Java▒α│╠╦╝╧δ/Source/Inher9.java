class Super{
  int a=10;
  void hi(){
    System.out.println("�ȳ�~~");
  }
}
class Sub extends Super{
  int b=20;
  void hi(){
    System.out.println("hi~~");	
  }
  void bye(){
    System.out.println("����~~");	
  }
}
public class Inher9{
  public static void main(String[] args){
    Super ob=new Sub();
    ob.a=20;
    ob.hi();
  }
}