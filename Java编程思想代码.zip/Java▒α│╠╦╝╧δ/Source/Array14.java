public class Array14{
  static int max(int[] a){
    int m=a[0];
    for(int i=1;i<a.length;i++)
      if(a[i]>m)m=a[i];
    return m;  	
  }
  public static void main(String[] args){
     int[] k=new int[]{10, 34, 52, 97,83};
     System.out.println(max(k));
  }
}