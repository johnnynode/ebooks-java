import java.awt.*;
public class AWT3{
  public static void main(String[] args) throws Exception{
     Frame f=new Frame("������Ʈ�� ũ��� ��ġ");
     f.setSize(200,100);
     f.setVisible(true);
     for(int i=0;i<=255;i++){
  	    f.setBackground(new Color(i, 0, 0));
  	    Thread.sleep(10);
  	 }
  	 for(int i=0;i<=255;i++){
  	    f.setBackground(new Color(255, i, 0));
  	    Thread.sleep(10);
  	 }
  }
}