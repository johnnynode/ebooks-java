public class Class23{
  void hi(){
  	System.out.println("�ȳ�~~");
  }	
  int hi(){
    System.out.println("�� �ȳ�~~");
    return 1;
  }
  public static void main(String[] args){
    Class23 ob=new Class23();
    ob.hi();
  }
}