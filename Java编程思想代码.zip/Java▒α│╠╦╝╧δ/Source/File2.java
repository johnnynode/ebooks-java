import java.io.*;
public class File2{
  public static void main(String[] args){
    File f=new File("C:\\autoexec.bat");
    System.out.println(f.isFile());
    System.out.println("�̸�: "+f.getName());
    System.out.println("���丮: "+f.getParent());
    System.out.println("���: "+f.getPath());
    System.out.println("ũ��: "+f.length()+" bytes");
  }
}
