public class Operator8{
  public static void main(String[] args){
  	  int a=10;
      System.out.println((a=20)==20);
      System.out.println(a);
   	}
}