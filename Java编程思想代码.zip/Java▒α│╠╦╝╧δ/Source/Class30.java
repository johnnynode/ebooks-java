public class Class30{
  public Class30(){
    System.out.println("�ȳ�~~");
  }
  public Class30(String s){
  	this();
  	System.out.println(s);
  }
  public Class30(int a){
  	this("�ݰ���~~");
  	System.out.println(a);
  }
  public static void main(String[] args){
    Class30 ob=new Class30(20);
  }
}