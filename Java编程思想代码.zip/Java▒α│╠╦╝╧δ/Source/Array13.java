public class Array13{
  public static void main(String[] args){
    int[] a,b;
    b=new int[3];
    b[0]=30;
    System.out.println(b[0]);
  }
}