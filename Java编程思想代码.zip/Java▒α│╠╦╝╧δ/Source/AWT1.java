import java.awt.*;
public class AWT1{
  public static void main(String[] args){
     Frame f=new Frame("�����ϴ� �ڹ�");
     f.setSize(200,100);
     f.setVisible(true);
  }	
}