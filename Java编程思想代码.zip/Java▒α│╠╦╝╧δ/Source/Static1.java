class Outer{
   static int a=10;
   int b=20;
   static void f(){
     System.out.println("hi~~");	
   }	
   static class Inner{
   	 int c=30;
   	 public void g(){
       f();
       System.out.println(a+" "+c);	
   	 }
   }
}
public class Static1{
  public static void main(String[] args){
     Outer.Inner ob=new Outer.Inner();
     ob.g();
  }
}
