public class Array7{
  public static void main(String[] args){
    int[] a=new int[2];
    String[] b=new String[2];
    System.out.println(a[0]+" "+a[1]);
    System.out.println(b[0]+" "+b[1]);
  } 
}