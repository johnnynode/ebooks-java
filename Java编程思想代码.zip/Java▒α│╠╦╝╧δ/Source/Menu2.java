import java.awt.*;
import java.awt.event.KeyEvent;
public class Menu2{
  public static void main(String[] args){
    Frame f=new Frame("Menu");
    MenuBar mb=new MenuBar();
    Menu m_File=new Menu("����");
    Menu m_Edit=new Menu("����");
    Menu m_View=new Menu("����");
    MenuItem mi_New=
       new MenuItem("����",new MenuShortcut(KeyEvent.VK_N));
    MenuItem mi_Open=
       new MenuItem("����",new MenuShortcut(KeyEvent.VK_O));
    MenuItem mi_Save=
       new MenuItem("����",new MenuShortcut(KeyEvent.VK_S));
    MenuItem mi_Exit=
       new MenuItem("����",new MenuShortcut(KeyEvent.VK_X));
    
    m_File.add(mi_New);
    m_File.add(mi_Open);
    m_File.add(mi_Save);
    m_File.addSeparator();
    m_File.add(mi_Exit);
    
    mb.add(m_File);
    mb.add(m_Edit);
    mb.add(m_View);
    
    f.setMenuBar(mb);
    f.setSize(200,200);
    f.setVisible(true);
  }
}