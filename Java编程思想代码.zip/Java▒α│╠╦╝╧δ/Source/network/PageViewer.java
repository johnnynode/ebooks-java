import java.awt.*;
import java.net.*;
import java.io.*;
import java.awt.event.*;
public class PageViewer extends Frame {
  private TextField tURL=new TextField("");
  private TextArea tPage=new TextArea();
  private BufferedReader reader;
  public PageViewer(String title){
    super(title);
    tPage.setEditable(false);
    add(tURL,"North");
    add(tPage,"Center");
    tURL.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ae){
        try{
          readPage(new URL(tURL.getText()));
        }catch(MalformedURLException ie){
          tPage.setText("URL�� �߸��Ǿ����ϴ�.");  
        }
      }
    });
  }
  void readPage(URL url){
    tPage.setText("");
    String line;
    try{
      reader=new BufferedReader(new InputStreamReader(url.openStream()));
      while((line=reader.readLine())!=null)
        tPage.append(line+"\n");
    }catch(IOException ie){
      tPage.setText("����� ���ܰ� �߻��Ͽ����ϴ�.");  
    }finally{
       try{
         if(reader!=null)reader.close();
       }catch(Exception e){}
    }
  }
  public static void main(String[] args){
    PageViewer me=new PageViewer("Page Viewer");
    me.setSize(400,400);
    me.setVisible(true);
  }
}