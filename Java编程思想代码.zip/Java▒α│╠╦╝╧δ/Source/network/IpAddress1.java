import java.net.*;
public class IpAddress1{
  public static void main(String[] args){
    InetAddress ip=null;
    try{
      ip=InetAddress.getByName("java.pukyung.co.kr");
      System.out.println("ȣ��Ʈ �̸�: "+ ip.getHostName());
      System.out.println("ȣ��Ʈ IP �ּ�: "+ ip.getHostAddress());
      System.out.println("����ȣ��Ʈ IP �ּ�: "+
                        InetAddress.getLocalHost().getHostAddress());
    }catch(UnknownHostException ue){
      System.out.println(ue);  
    }
  }
    
}