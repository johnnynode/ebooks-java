public class Array10{
  public static void main(String[] args){
    int[][] a;
    a=new int[3][];
    int[] sum=new int[3];
    a[0]=new int[]{100,80,80,75,90};
    a[1]=new int[]{50,60,60,65,55};
    a[2]=new int[]{100,100,100,100,100};
    
    for(int i=0;i<a.length;i++)
     for(int j=0;j<a[i].length;j++)
       sum[i]+=a[i][j];
    
    for(int i=0;i<sum.length;i++)
    System.out.println("�հ�= "+sum[i]);
    
  } 
}