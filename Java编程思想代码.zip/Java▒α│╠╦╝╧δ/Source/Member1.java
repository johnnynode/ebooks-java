class Outer{
   static int a=10;
   int b=20;
   void f(){
     System.out.println("hi~~");	
   }	
   class Inner{
   	 int c=30;
   	 public void g(){
   	   b=100;
       f();
       System.out.println(a+" "+c);	
   	 }
   }
}
public class Member1{
  public static void main(String[] args){
     Outer out=new Outer();
     Outer.Inner in=out.new Inner();
     in.g();
     System.out.println(out.b);
  }
}
