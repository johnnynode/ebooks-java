public class Class28{
  int a;
  public void Class28(){
  	a=10;
  }
  public static void main(String[] args){
    Class28 ob=new Class28();
    System.out.println(ob.a);
  }
}