import java.awt.*;
public class Checkbox3{
  public static void main(String[] args) throws Exception{
    Frame frame=new Frame("����ִ� ���α׷���");
    frame.setLayout(new GridLayout(10,10));
    
    CheckboxGroup cbg=new CheckboxGroup();
    Checkbox[] cb=new Checkbox[100];
       
    for(int i=0;i<cb.length;i++){
      cb[i] = new Checkbox("", false, cbg);
      frame.add(cb[i]);
    }
    frame.pack();
    frame.setVisible(true);
    int a=0;
    while(true){
      cb[a].setState(true);
      Thread.sleep(50);
      a++;
      if(a>=cb.length)a=0;
    }
  }
}