public class Class26{
  int a;
  public Class26(){
  	a=10;
  } 		
  public static void main(String[] args){
    Class26 ob=new Class26();
    System.out.println(ob.a);
  }
}