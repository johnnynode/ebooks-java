public class Class33{
   int a;
   {
     System.out.println("�ν��Ͻ� ����");
     a=10;
   }
   Class33(int a){
   	 System.out.println("������");
   	 this.a=a;
   }
  public static void main(String[] args){
     Class33 ob=new Class33(30);
     System.out.println(ob.a);
  }
}