import java.io.*;
public class File9{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\ȫ�浿.dat");
    FileOutputStream fos=new FileOutputStream(f);
    DataOutputStream dos=new DataOutputStream(fos);
    dos.writeUTF("ȫ�浿");
    dos.writeInt(20);
    dos.writeInt(180);
    dos.writeUTF("�ѱ�");
    dos.close();
    System.out.println("������ �ۼ��Ǿ����ϴ�.");
  }
}
