import java.awt.*;
import java.awt.event.*;
public class WindowEvent1 extends Frame implements WindowListener{
  public WindowEvent1(){
  	setTitle("������ �̺�Ʈ ó��");
    addWindowListener(this);
  }
  public void windowClosing(WindowEvent e){
    Dialog d=new Dialog(this,"���� Ȯ��",true);
    Panel p=new Panel();
    p.setLayout(new GridLayout());
    p.add(new Button("��"));
    p.add(new Button("�ƴϿ�"));
    d.add(new Label("�շ��Ͻðڽ��ϱ�?",Label.CENTER),"Center");
    d.add(p,"South");
    d.setSize(200,100);
    d.setVisible(true);
  }
  public void windowClosed(WindowEvent e){}
  public void windowDeactivated(WindowEvent e){}
  public void windowActivated(WindowEvent e){}
  public void windowIconified(WindowEvent e){}
  public void windowDeiconified(WindowEvent e){}
  public void windowOpened(WindowEvent e){}
		
  public static void main(String[] args){
    WindowEvent1 me=new WindowEvent1();
    me.setSize(200,200);
    me.setVisible(true);
  }
}