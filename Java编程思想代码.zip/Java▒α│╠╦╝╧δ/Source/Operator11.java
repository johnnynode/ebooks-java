public class Operator11{
  public static void main(String[] args){
     System.out.println(true?10:20);
     System.out.println(false?10:20);
     System.out.println((3>2)&&(2<3)?10:20);
     int b=50>20&&30>10?50:100;
     System.out.println(b);
  }
}