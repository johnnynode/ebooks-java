public class Cloneable1 implements Cloneable{
  String s;
  int a;
  public Cloneable1(String s, int a){
    this.s=s;
    this.a=a; 
  }
  public Object clone(){
    try{
      return super.clone();
    }catch(CloneNotSupportedException cse){}
    return null;
  }
  public static void main(String[] args){
    Cloneable1 ob1 =new Cloneable1("abcd", 10);
    Cloneable1 ob2 =(Cloneable1)ob1.clone();
    
    System.out.println("����: "+ob1.hashCode());
    System.out.println("����: "+ob2.hashCode());
    System.out.println("����: "+ob1.s+"  "+ob1.a);
    System.out.println("����: "+ob2.s+"  "+ob2.a);
  }
}


