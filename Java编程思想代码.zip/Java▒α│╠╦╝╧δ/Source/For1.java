public class For1{
  public static void main(String[] args){
     for(int a=1;a<=5;a++){
        System.out.print(a+" ");
     }
  }	
}