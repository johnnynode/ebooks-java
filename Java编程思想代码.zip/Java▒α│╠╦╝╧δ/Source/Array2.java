public class Array2{
  public static void main(String[] args){
  	int[] a=new int[4];
  	int sum=0;
  	a[0]=90; a[1]=80; a[2]=75; a[3]=85;
  	for(int i=0;i<a.length;i++)
  	  sum+=a[i];
  	System.out.println("����: "+sum);
  	System.out.println("���: "+(double)sum/a.length);  
  }
}