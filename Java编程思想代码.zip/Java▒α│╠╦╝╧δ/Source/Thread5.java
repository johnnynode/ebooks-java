class SumThread extends Thread{
  int from, to;
  long sum;
  SumThread(int from, int to){
  	this.from=from;
  	this.to=to;
  }
  long getSum(){
  	return sum;
  }
  public void run(){
    for(int i=from;i<=to;i++)
      sum+=i;
  }
}
public class Thread5{
  public static void main(String[] args){
    SumThread st1=new SumThread(1,500);
    SumThread st2=new SumThread(501, 1000);
    st1.start();
    st2.start();
    try{
      st1.join();
      st2.join();
    }catch(InterruptedException ie){}
    long sum=st1.getSum()+st2.getSum();
    System.out.println("1~1000���� ��: "+sum);
  } 
}
