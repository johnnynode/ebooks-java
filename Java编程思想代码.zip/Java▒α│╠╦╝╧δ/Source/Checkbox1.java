import java.awt.*;
public class Checkbox1{
  public static void main(String[] args) throws Exception{
    Frame frame=new Frame("Checkbox");
    Checkbox cb1 = new Checkbox("����", true);
    Checkbox cb2 = new Checkbox("����", false);
    Checkbox cb3 = new Checkbox("����", true);
    
    frame.add(cb1);
    frame.add(cb2);
    frame.add(cb3);
    
    frame.setLayout(new FlowLayout());
    
    frame.setSize(200,70);
    frame.setVisible(true);
  }
}