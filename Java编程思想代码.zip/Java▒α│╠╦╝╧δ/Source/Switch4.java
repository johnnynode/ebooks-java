public class Switch4{
  public static void main(String[] args){
     char a='A',b=97,c='��';
     System.out.println((int)a);
     System.out.println((char)(a+1));
     System.out.println(b);
     System.out.println((int)c);
  }
}