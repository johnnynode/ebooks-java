public class Operator1{
  public static void main(String[] args){
      boolean b= true;
      System.out.println(!b);
  	  System.out.println(!!b);
  	}
}
