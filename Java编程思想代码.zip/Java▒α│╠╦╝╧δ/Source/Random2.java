import java.util.*;
public class Random2{
  public static void main(String[] args){
     Random rnd=new Random();
     String[] card={"��Ʈ1","��Ʈ2","��Ʈ3","��Ʈ4","��Ʈ5",
                    "��Ʈ6","��Ʈ7","��Ʈ8","��Ʈ9","��Ʈ10"};
     String temp;
     int a, b;
     for(int i=0;i<100;i++){
        a=rnd.nextInt(10);
        b=rnd.nextInt(10);
        temp=card[a];
        card[a]=card[b];
        card[b]=temp;
     }
     for(int i=0;i<10;i++){
        System.out.println(card[i]);
     }
  }	
}