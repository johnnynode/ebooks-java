public class Object14{
  int a,b;
  Object14(int a, int b){
    this.a=a;
    this.b=b;	
  }
  Object14 twice(){
  	return new Object14(2*a, 2*b);
  }
  public static void main(String[] args){
     Object14 ob1=new Object14(10, 20);
     Object14 ob2=ob1.twice();
     System.out.println(ob1.a+" "+ob1.b);
     System.out.println(ob2.a+" "+ob2.b);
  }
}
