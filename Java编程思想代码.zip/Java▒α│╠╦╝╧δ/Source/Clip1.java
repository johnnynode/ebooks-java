import java.awt.*;
import java.awt.geom.*;
public class Clip1 extends Frame{
  Image img;
  public Clip1(String title){
    super(title);
    img=getToolkit().getImage(getClass().getResource("/images/baby.gif"));  
  }
  public void paint(Graphics g){
    g.setClip(new Ellipse2D.Float(50,30,180,260));
    g.drawImage(img, 0,0, this);
  }
  public static void main(String[] args){
    Frame f=new Clip1("Ŭ����");
    f.setSize(300, 300);
    f.setVisible(true);
  }
}
