import java.io.*;
public class File5{
  public static void main(String[] args) throws Exception{
    FileOutputStream fos=new FileOutputStream("c:\\���ĺ�.txt",true);
    for(int i='a';i<='z';i++)
      fos.write(i);
    fos.close();  
  }
}
