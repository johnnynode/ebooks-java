import java.awt.*;
public class AWT2{
  public static void main(String[] args) throws Exception{
     Frame f=new Frame("������Ʈ�� ũ��� ��ġ");
     f.setVisible(true);
     for(int i=1;i<=5;i++){
  	    f.setSize(i*100,i*100);	
  	    f.setLocation(i*10,i*10);
  	    System.out.println("�ʺ�="+ f.getWidth());
  	    Thread.sleep(1000);
  	 }
  }	
}