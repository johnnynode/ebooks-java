public class Math3{
  public static void main(String[] args){
  	System.out.println(Math.abs(3.4));
  	System.out.println(Math.abs(-3.4));
  	System.out.println(Math.max(10, 20));
  	System.out.println(Math.min(10, 20));
  }
}
















