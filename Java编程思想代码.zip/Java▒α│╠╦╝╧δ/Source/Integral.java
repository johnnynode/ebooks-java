public class Integral{
  public static void main(String[] args){
    byte  b=1L;
    short s=32000;
    int   i=-2100000000;
    long  l=1234567890123456890L;
    System.out.println(b);
    System.out.println(s);
    System.out.println(i);
    System.out.println(l);   
  }
}

