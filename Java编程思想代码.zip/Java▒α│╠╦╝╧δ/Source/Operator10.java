public class Operator10{
  public static void main(String[] args){
      int a=14, b=12;
      System.out.println(a&b);
      
   	}
}