class MyRunnable implements Runnable{
  String name;
  MyRunnable(String name){
  	this.name=name;
  }
  public void run(){
    for(int i=1;i<=10;i++)
      System.out.println(name+": "+i);
  }
}
public class Thread1{
  public static void main(String[] args){
     MyRunnable myr=new MyRunnable("myrunable");
     Thread t=new Thread(myr);
     t.start();
  }
}
