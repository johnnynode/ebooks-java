import java.awt.*;
import java.net.*;
public class Url1{
  public static void main(String[] args){
    Url1 ob=new Url1();
    Class cl= ob.getClass();
    URL url=cl.getResource("Url1.java");
    System.out.println(cl.toString());
    System.out.println(url.toString());
  }
    
}