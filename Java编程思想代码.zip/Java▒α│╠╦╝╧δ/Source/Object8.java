public class Object8{
  private int a;
  public Object8(int a){
  	this.a=a;
  }
  public void twice(Object8 o){
  	o.a*=2;
  }
  public int getA(){
  	return a;
  }
  public static void main(String[] args){
    Object8 ob=new Object8(100);
    ob.twice(ob);
    System.out.println(ob.getA());
  }
}
