public class Math1{
  public static void main(String[] args){
  	double a=Math.sin(Math.PI/2);
    System.out.println(a);
    double b=Math.cos(Math.toRadians(60));
    System.out.println(b);
    System.out.println(Math.log(Math.E));
    System.out.println(Math.sqrt(9));
  }
}
















