class Person{
  private String name;
  private Person friend;
  Person(String name){
    this.name = name;
  }
  void setFriend(Person friend){
    this.friend = friend; 
  }
  String getName(){
    return name;
  }
  String getFriendName(){
    return friend.name;
  }
}
public class Self1{
  public static void main(String[] args){
    Person man1 = new Person("���غ�");
    Person man2 = new Person("�ڼ���");
    man1.setFriend(man2);
    man2.setFriend(man1);
    System.out.println(man1.getName()+"�� ģ��: "+man1.getFriendName());
    System.out.println(man2.getName()+"�� ģ��: "+man2.getFriendName());
  }
}