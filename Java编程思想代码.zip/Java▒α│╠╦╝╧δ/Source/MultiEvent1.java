import java.awt.*;
import java.awt.event.*;
public class MultiEvent1 extends Frame implements ActionListener, TextListener{
  Label action=new Label();
  Label text=new Label();
  TextField tf=new TextField(20);
  public MultiEvent1(String title){
  	super(title);
  	action.setBackground(Color.GREEN);
  	text.setBackground(Color.PINK);
  	add(action,"North");
  	add(text,"Center");
  	add(tf,"South");
  	tf.addActionListener(this);
  	tf.addTextListener(this);
  }
  public void actionPerformed(ActionEvent e){
  	action.setText(tf.getText());
  }
  public void textValueChanged(TextEvent e){
  	text.setText(tf.getText());
  } 
  public static void main(String[] args){
    Frame f=new MultiEvent1("���� �̺�Ʈ ó��");
    f.pack();
    f.setVisible(true);    
  }
}