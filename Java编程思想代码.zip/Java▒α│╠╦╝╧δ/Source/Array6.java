public class Array6{
  public static void main(String[] args){
    String[] s1={new String("abc"), new String("kor")};
    String[] s2=new String[]{new String("�ȳ�"), new String("�氡")};
    System.out.println(s1[0]);
    System.out.println(s2[1]);
  }
}
