class Man{
  int height;
  int age;
}

public class Class2{
  public static void main(String[] args){
     Man man1=new Man();
     Man man2;
     man2=man1;
     man1.height=180;
     man1.age=20;
     System.out.println(man2.height);
     System.out.println(man2.age); 	
  }
}