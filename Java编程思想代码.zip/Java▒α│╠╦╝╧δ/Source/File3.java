import java.io.File;

public class File3{
  public static void main(String[] args){
    File f=new File("c:\\");
    File[] fs=f.listFiles();
    for(int i=0;i<fs.length;i++){
      if(fs[i].isDirectory())
           System.out.print("���丮: ");
      else System.out.print("����: ");
      System.out.println(fs[i]);
    }  
  }
}
