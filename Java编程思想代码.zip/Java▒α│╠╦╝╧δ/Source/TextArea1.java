import java.awt.*;
import java.io.*;
public class TextArea1{
  public static void main(String[] args) throws IOException{
    Frame frame=new Frame("���� ����");
    TextArea ta=new TextArea(20,50);
    String aline;
    BufferedReader br=new BufferedReader(
    	           new FileReader("TextArea1.java"));
    
    while((aline=br.readLine())!=null)
      ta.append(aline+'\n');
    br.close();
    
    frame.add(ta);
    frame.pack();
    frame.setVisible(true);
  }
}