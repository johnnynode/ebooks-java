public class Class32{
   static int b;
   static{
     System.out.println("����~~");
     b=30;
   }
  public static void main(String[] args){
    System.out.println("��~~");
    System.out.println(b);
  }
}