public class Array3{
  public static void main(String[] args){
  	int[] a=new int[]{12, 22, 37, 48, 59};
    double[] b={1.2, -2.7, 9.53, 3.0};
    System.out.println(a.length);
    System.out.println(b.length);
    System.out.println(a[1]);
    System.out.println(b[2]);
  }
}