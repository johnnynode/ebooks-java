public class Deprecation2 extends Thread{
  boolean runnable=true;
  void stopThread(){
  	runnable=false;
  }
  public void run(){
  	while(runnable)
  	 System.out.println("Hi~~~");
  }	
  public static void main(String[] args){
  	Deprecation2 dt=new Deprecation2();
  	dt.start();
  	try{
  	  Thread.sleep(1000);
  	}catch(InterruptedException ie){}
  	dt.stopThread();
    System.out.println("������ ����");
  }
}