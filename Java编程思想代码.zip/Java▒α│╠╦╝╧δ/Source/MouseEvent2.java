import java.awt.*;
import java.awt.event.*;
public class MouseEvent2 extends Frame{
  Label mouseInfo;
  public MouseEvent2(String title){
  	super(title);
  	mouseInfo=new Label("");
    mouseInfo.setBackground(Color.YELLOW);
  	add(mouseInfo,"North");
	
  	this.addMouseMotionListener(new MouseMotionHandler());  	
  }
  public static void main(String[] args){
    MouseEvent2 me=new MouseEvent2("Mouse ������ ó��");
    me.setSize(200,200);
    me.setVisible(true);
  }
  class MouseMotionHandler implements MouseMotionListener{
  	public void mouseMoved(MouseEvent e){
  	  mouseInfo.setText("move -> x: " +e.getX()+" y: "+e.getY());
  	}
  	public void mouseDragged(MouseEvent e){
  	  mouseInfo.setText("drag -> x: " +e.getX()+" y: "+e.getY());
  	}
  }
}