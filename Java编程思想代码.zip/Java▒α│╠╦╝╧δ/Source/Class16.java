package Mypack.pack1;

public class Class16{
  public void hi(){
    System.out.println("���̿�~~~~");
  }
}