import java.util.*;
public class Calendar1{
  public static void main(String[] args){
    GregorianCalendar gc= new GregorianCalendar();
    String now = gc.get(Calendar.YEAR)+"��"
                +(gc.get(Calendar.MONTH)+1)+"��"
                +gc.get(Calendar.DATE)+"��"
                +gc.get(Calendar.HOUR)+"��"
                +gc.get(Calendar.MINUTE)+"��"
                +gc.get(Calendar.SECOND)+"."
                +gc.get(Calendar.MILLISECOND)+ "��";
    System.out.println("���� �ð��� " + now +" �Դϴ�.");
  }
}