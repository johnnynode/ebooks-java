public class Object10{
  static void play(String name){
  	 String a=name+"�� ����.";
  	 System.out.println(a);
  }	
  public static void main(String[] args){
     play(new String("ö��"));
  }
}
