public class Operator12{
  public static void main(String[] args){
     int a=2;
     a+=2;
     System.out.println(a);
     a^=2;
     System.out.println(a);
     a<<=1;
     System.out.println(a);
     a|=2;
     System.out.println(a);
     a%=2;
     System.out.println(a);
  }
}