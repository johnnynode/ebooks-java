class Anony2_1{
  public void hi(){
    System.out.println("hi?");
  }
  public void hello(){
    System.out.println("hello?");
  }
}
public class Anony2{
  public static void main(String[] args){
    Anony2_1 ob=new Anony2_1(){
      public void hi(){
     	  System.out.println("�ȳ�?");
     	}
    };
    ob.hi();
    ob.hello();
  }
}
