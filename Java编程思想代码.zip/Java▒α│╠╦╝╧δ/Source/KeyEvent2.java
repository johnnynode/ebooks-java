import java.awt.*;
import java.awt.event.*;
public class KeyEvent2 extends Frame{
  Label info;
  TextField tf;
  public KeyEvent2(String title){
  	super(title);
  	setLayout(new GridLayout(2,1));
  	
  	info=new Label("Ű ����: ");
  	tf=new TextField();
  	
  	add(info);
  	add(tf);
  	tf.addKeyListener(new KeyHandler());
  }
  public static void main(String[] args){
    KeyEvent2 me=new KeyEvent2("Key �̺�Ʈ ó��");
    me.setSize(200,200);
    me.setVisible(true);
  }
  class KeyHandler extends KeyAdapter{
  	public void keyPressed(KeyEvent e){
      String k="";
      if(e.isShiftDown())k="Shift + ";
      if(e.isAltDown())k+="Alt + ";
      if(e.isControlDown())k+="Ctrl + ";
      k+=e.getKeyText(e.getKeyCode());
      info.setText("Ű ����: " + k);
  	}
  }
}