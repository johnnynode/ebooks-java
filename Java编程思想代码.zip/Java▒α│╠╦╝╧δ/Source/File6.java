import java.io.*;
public class File6{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\���ĺ�.txt");
    FileInputStream fis=new FileInputStream(f);
    char a;
    for(int i=0;i<f.length();i++){
      a=(char)fis.read();
      System.out.print(a);
    }
    fis.close();
  }
}
