public class Recursion1{
  static void hi(int n){
    if(n<=0) return;
    hi(n-1);
    System.out.println("�ȳ� "+ n );
  }
  public static void main(String[] args){
    hi(3000);
  }
}