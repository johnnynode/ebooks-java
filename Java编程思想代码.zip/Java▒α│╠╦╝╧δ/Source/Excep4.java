public class Excep4{
  public static void main(String[] args){
     int[] a=new int[5];
     try{
       a[10]=200;
     }catch(ArithmeticException e){
      	System.out.println(e);
     }catch(NullPointerException e){
       System.out.println(e);
     }catch(ArrayIndexOutOfBoundsException e){
       System.out.println(e);
     }finally{
       System.out.println("������ ����");
     }
  }
}