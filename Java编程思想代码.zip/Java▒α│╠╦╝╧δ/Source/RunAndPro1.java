import java.lang.Runtime;
public class RunAndPro1{
  public static void main(String[] args) throws Exception{
     Runtime rt=Runtime.getRuntime();
     Process pr=rt.exec("c:\\windows\\notepad.exe");
     System.out.println("�ִ� �޸�: "+rt.maxMemory()+"bytes");
     System.out.println("��Ż �޸�: "+rt.totalMemory()+"bytes");
     System.out.println("���� �޸�: "+rt.freeMemory()+"bytes");
  }
}
