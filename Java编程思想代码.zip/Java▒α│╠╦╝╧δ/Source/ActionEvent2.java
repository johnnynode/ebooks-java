import java.awt.*;
import java.awt.event.*;
public class ActionEvent2 extends Frame implements ActionListener{
  TextField tf;
  public ActionEvent2(String title){
  	super(title);
  	tf=new TextField(20);
  	tf.addActionListener(this);
  	add(tf);
  }
  public void actionPerformed(ActionEvent e){
  	 if(e.getSource() instanceof TextField){
  	   TextField temp=(TextField)e.getSource();
  	   System.out.println(temp.getText());
  	   temp.setText("");
     }
  }
  public static void main(String[] args){
    ActionEvent2 me=new ActionEvent2("�׼� �̺�Ʈ ó��");
    me.pack();
    me.setVisible(true);
  }
}