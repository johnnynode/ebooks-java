import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.datatransfer.*;

class MyMenuBar extends MenuBar{
  public MyMenuBar(Frame parent){
    parent.setMenuBar(this);
  }
  public void addMenus(String[] menus){
     for(int i=0;i<menus.length;i++)
       add(new Menu(menus[i]));
  }
  public void addMenuItems(int menuNumber,String[] items){
     for(int i=0;i<items.length;i++){
       if(items[i]!=null)
         getMenu(menuNumber).add(new MenuItem(items[i]));
       else getMenu(menuNumber).addSeparator();
     }  
  }
  public void addActionListener(ActionListener al){
    for(int i=0;i<getMenuCount();i++)
      for(int j=0;j< getMenu(i).getItemCount();j++)
        getMenu(i).getItem(j).addActionListener(al);
  }
}
class MyFile{
  private FileDialog fDlg;
     
  public MyFile(Frame parent){
    fDlg=new FileDialog(parent,"",FileDialog.LOAD); 
  }
  private String getPath(){
    return fDlg.getDirectory()+"\\"+fDlg.getFile();
  }
  public String getData() throws IOException{
    fDlg.setTitle("����");
    fDlg.setMode(FileDialog.LOAD);
    fDlg.setVisible(true);
    BufferedReader br=
            new BufferedReader(new FileReader(getPath()));
    StringBuffer sb=new StringBuffer();
    String aline;
    while((aline=br.readLine())!=null)
      sb.append(aline+'\n');  
    br.close();   
    return sb.toString();   
  }
  public void setData(String data) throws IOException{
    fDlg.setTitle("����");
    fDlg.setMode(FileDialog.SAVE);
    fDlg.setVisible(true);
    BufferedWriter bw=
            new BufferedWriter(new FileWriter(getPath()));  
    bw.write(data);
    bw.close();
  }
}
class MyClipboard{
  private Clipboard cb;
  public MyClipboard(){
    cb=Toolkit.getDefaultToolkit().getSystemClipboard();  
  }  
  public void setData(String data){
    cb.setContents(new StringSelection(data),null);
  }
  public String getData(){
    Transferable content=cb.getContents(null);
      try{
        return (String)content.getTransferData(DataFlavor.stringFlavor);
      }catch(Exception ue){}
    return null;  
  }
}
class MyFindDialog extends Dialog implements ActionListener{
  private Label lFind=new Label("ã�� ���ڿ�:");
  private Label lReplace=new Label("�ٲ� ���ڿ�:");
  private TextField tFind=new TextField(10);
  private TextField tReplace=new TextField(10);
  private Button bFind=new Button("ã��");
  private Button bReplace=new Button("�ٲٱ�");
  private TextArea ta;
  public MyFindDialog(Frame owner, TextArea ta){
    super(owner,"ã��",false);
    this.ta=ta;
    setLayout(null);
    lFind.setBounds(10,30,80,20);
    lReplace.setBounds(10,70,80,20);
    tFind.setBounds(90,30,90,20);
    tReplace.setBounds(90,70,90,20);
    bFind.setBounds(190,30,80,20);
    bReplace.setBounds(190,70,80,20);
    add(lFind);
    add(tFind);
    add(bFind);
    add(lReplace);
    add(tReplace);
    add(bReplace);
    setResizable(false);
    bFind.addActionListener(this);
    bReplace.addActionListener(this);
    addWindowListener( new WindowAdapter(){
         public void windowClosing(WindowEvent e){
           MyFindDialog.this.dispose();
         }
    });
  }
  public void showFind(){
    setTitle("ã��");
    setSize(280,60);
    setVisible(true);
  }
  public void showReplace(){
    setTitle("ã�� �ٲٱ�");
    setSize(280,110);
    setVisible(true);
  }
 
  private void find(){
    String text=ta.getText();
    String str=tFind.getText();
    int end=text.length();
    int len=str.length();
    int start=ta.getSelectionEnd();
    if(start==end)start=0;
    for( ;start<=end-len;start++){
      if(text.substring(start,start+len).equals(str)){
         ta.setSelectionStart(start);
         ta.setSelectionEnd(start+len);
         return;
      }
    }
    ta.setSelectionStart(end);
    ta.setSelectionEnd(end);
  }
  private void replace(){
    String str=tReplace.getText();
    if(ta.getSelectedText().equals(tFind.getText()))
      ta.replaceRange(str,ta.getSelectionStart(),ta.getSelectionEnd());   
    else find();
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource()==bFind)
      find();
    else if(e.getSource()==bReplace)
      replace();
  }
}
public class MyMemo extends Frame implements ActionListener{
  private TextArea editor=new TextArea();
  private MyFile mf=new MyFile(this);
  private MyClipboard cb=new MyClipboard();
  private MyFindDialog findDlg=new MyFindDialog(this,editor);
  public MyMemo(String title){
    super(title);
    MyMenuBar mb=new MyMenuBar(this);
    mb.addMenus(new String[]{"����","����","ã��","����"});
    mb.addMenuItems(0, new String[]{"����","����","����",null,"����"});
    mb.addMenuItems(1, new String[]{"�߶󳻱�","�����ϱ�","�ٿ��ֱ�","�����",null,"��ü����"});
    mb.addMenuItems(2, new String[]{"ã��",null,"ã�� �ٲٱ�"});
    mb.addMenuItems(3, new String[]{"���� �޸��� ����"});
    add(editor);
    mb.addActionListener(this);
    addWindowListener( new WindowAdapter(){
         public void windowClosing(WindowEvent e){
           MyMemo.this.dispose();
         }
    });
  }
  
  public void actionPerformed(ActionEvent e){
    String selected =e.getActionCommand();
    if(selected.equals("����"))
      editor.setText("");
    else if(selected.equals("����")){
      try{
        editor.setText(mf.getData());
      }catch(IOException ie){}
    }
    else if(selected.equals("����")){
      try{
        mf.setData(editor.getText());
      }catch(IOException ie){}
    }
    else if(selected.equals("����")){
      dispose();
    }
    else if(selected.equals("�߶󳻱�") ){
      cb.setData(editor.getSelectedText());
      editor.replaceRange("",editor.getSelectionStart(),editor.getSelectionEnd());
    }
    else if(selected.equals("�����ϱ�") ){
      cb.setData(editor.getSelectedText());
    }
    else if(selected.equals("�ٿ��ֱ�") ){
      String str=cb.getData();
      editor.replaceRange(str,editor.getSelectionStart(),editor.getSelectionEnd());
    }
    else if(selected.equals("�����") ){
      editor.replaceRange("",editor.getSelectionStart(),editor.getSelectionEnd());
    }
    else if(selected.equals("��ü����") ){
      editor.setSelectionStart(0);
      editor.setSelectionEnd(editor.getText().length());
    }
    else if(selected.equals("ã��") ){
      findDlg.showFind();
    }
    else if(selected.equals("ã�� �ٲٱ�") ){
      findDlg.showReplace();
    }
}
  public static void main(String[] args){
    MyMemo memo=new MyMemo("������ �޸���");
    memo.setSize(300,300);
    memo.setVisible(true);    
  }
}