import java.awt.*;
public class List1{
  public static void main(String[] args) throws Exception{
    Frame frame=new Frame("List Test");
    List list=new List(7);
    TextField tf=new TextField();
    list.add("�ſ���");
    list.add("������");
    list.add("������");
    list.add("�ڿ���");
    list.add("�Ͻ¶�");
    list.add("�̽�ȭ");
    frame.add(list,"Center");
    frame.add(tf,"South");
    frame.pack();
    frame.setVisible(true);
    for(int i=0;i<list.getItemCount();i++){
       tf.setText(list.getItem(i));
       Thread.sleep(1000);	
    }
  }
}