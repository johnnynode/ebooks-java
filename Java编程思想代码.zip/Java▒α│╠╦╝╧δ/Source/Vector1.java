import java.util.*;
public class Vector1{
  public static void main(String[] args){
     Vector v=new Vector();
     v.addElement("�ȳ�");
     v.addElement(new Integer(7));
     v.addElement(new Double(5.2));
     v.addElement(new StringBuffer("abc"));
     v.addElement("����");
     
     for(int i=0;i<v.size();i++){
       System.out.println(v.elementAt(i));	
     }
  }
}
