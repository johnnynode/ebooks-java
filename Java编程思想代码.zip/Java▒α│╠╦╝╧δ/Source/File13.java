import java.io.*;
public class File13{
  public static void main(String[] args) throws Exception{
    FileInputStream fis=new FileInputStream("c:\\autoexec.bat");
    InputStreamReader isr=new InputStreamReader(fis);
    BufferedReader br=new BufferedReader(isr);
    String s;
    while((s=br.readLine())!=null)
      System.out.println(s);
    br.close();
  }
}
