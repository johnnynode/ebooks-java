import java.awt.*;
import java.awt.event.*;
public class ItemEvent1 extends Frame implements ItemListener{
  List good=new List(7);
  TextField tf=new TextField();

  public ItemEvent1(String title){
  	super(title);
  	good.add("�ſ���");
    good.add("������");
    good.add("������");
    good.add("�ڿ���");
    good.add("�Ͻ¶�");
    good.add("�̽�ȭ");
    good.addItemListener(this);
    add(good,"North");
    add(tf,"Center");
  }
  public void itemStateChanged(ItemEvent e){
  	if( e.getSource()==good){
      tf.setText(good.getSelectedItem());
    }
    System.out.println(e.getItem());
  }
  public static void main(String[] args) throws Exception{
    ItemEvent1 f=new ItemEvent1("������ �̺�Ʈ ó��");
    
    f.pack();
    f.setVisible(true);
  }
  
}