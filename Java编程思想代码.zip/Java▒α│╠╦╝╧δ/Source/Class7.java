public class Class7{
  int sum(int a, int b){
  	 return a+b;
  }
  int average(int a, int b, int c){
  	 return (a+b+c)/3;
  }
  public static void main(String[] args){
     Class7 aaa=new Class7();
     int �հ�=aaa.sum(10,20);
     int ���=aaa.average(10,20,30);
     System.out.println("�հ�= "+�հ�);
     System.out.println("���= "+���);
  }
}