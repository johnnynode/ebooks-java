import java.math.BigInteger;
public class BigInteger1{
  public static void main(String[] args){
     BigInteger a=new BigInteger("123456789123456789");
     BigInteger b=new BigInteger("123456789123456789");
     BigInteger c=a.add(b);
     System.out.println(c);
     BigInteger d=a.subtract(b);
     System.out.println(d);
     BigInteger e=a.multiply(b);
     System.out.println(e);
     BigInteger f=a.divide(b);
     System.out.println(f);
     BigInteger g=new BigInteger("2");
     System.out.println(g.pow(3));
  }
}






















