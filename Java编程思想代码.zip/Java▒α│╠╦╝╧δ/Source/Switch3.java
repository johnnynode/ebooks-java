public class Switch3{
  public static void main(String[] args){
     int a=1;
     switch(a){
       case 1:  System.out.println("111");
       case 2:  System.out.println("222");
                break;
       case 3:  System.out.println("333");
       default: System.out.println("����");
     }
  }
}