public class String4{
  public static void main(String[] args){
    String s1=new String("This is a String");
    System.out.println(s1.length());
    System.out.println(s1.replace('i','Q'));
    System.out.println(s1.replaceAll("is","IS"));
    System.out.println(s1.startsWith("This"));
    System.out.println(s1.substring(5));
    System.out.println(s1.substring(5,13));
  }
}






















