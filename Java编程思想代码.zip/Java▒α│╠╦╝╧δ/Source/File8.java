import java.io.*;
public class File8{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\�빮��.txt");
    FileOutputStream fos=new FileOutputStream(f);
    FilterOutputStream filter=new FilterOutputStream(fos);
    for(int i='A'; i<='Z';i++)
      filter.write(i);
    filter.close();
  }
}
