public class Thread7 extends Thread{
  public void run(){
  	for(int i=1;i<=10;i++){
  	  System.out.println(getName()+": "+i);
  	  try{
  	   sleep(1000);
  	  }catch(InterruptedException ie){} 
  	}
  }
  public static void main(String[] args){
    Thread7 t1=new Thread7();
    t1.start();
  } 
}
