interface Inter{
  public void hi();	
}
public class Anony1{
  public static void main(String[] args){
    Inter ob1=new Inter(){
      public void hi(){
        System.out.println("�ȳ�~~~");
      }
    };
    Inter ob2=new Inter(){
      public void hi(){
        System.out.println("hello~~~");
      }
    };

    ob1.hi();
    ob2.hi();
  }
}
