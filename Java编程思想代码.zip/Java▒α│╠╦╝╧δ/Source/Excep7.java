public class Excep7{
  static void go() throws NegativeArraySizeException{
    int[] a=new int[-1];
  }
  static void hi() throws NegativeArraySizeException{
    go();
  }
  public static void main(String[] args){
    try{
      hi();
    }catch(NegativeArraySizeException e){
      System.out.println("�ָ��� ���� �Գ�..");
    }
  } 
}