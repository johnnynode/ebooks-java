public class Deprecation1 extends Thread{ 
  public void run(){
  	while(true)
  	 System.out.println("Hi~~~");
  }	
  public static void main(String[] args){
  	Deprecation1 dt=new Deprecation1();
  	dt.start();
  	dt.stop();
  }
}