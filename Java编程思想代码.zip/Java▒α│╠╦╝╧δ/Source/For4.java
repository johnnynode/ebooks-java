public class For4{
  public static void main(String[] args){
     for(int a=10;a>=1;a--){
        System.out.print(a+" ");
     }
  }	
}