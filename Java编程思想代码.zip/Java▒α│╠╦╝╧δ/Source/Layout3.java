import java.awt.*;
public class Layout3{
  public static void main(String[] args){
     Frame f=new Frame("Panel�� �̿��� ��ġ");
     f.add(new Button("NORTH"),BorderLayout.NORTH);
     f.add(new Button("WEST"),BorderLayout.WEST);
     f.add(new Button("CENTER"),BorderLayout.CENTER);
     f.add(new Button("EAST"),BorderLayout.EAST);
     Panel p=new Panel();
     p.add(new Button("������"));    
     p.add(new Button("7��"));
     p.add(new Button("�̴�..."));
     f.add(p,BorderLayout.SOUTH);
     f.pack();
     f.setVisible(true);
  }
}