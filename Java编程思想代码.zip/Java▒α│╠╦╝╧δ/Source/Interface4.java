interface MyInter1{
  public void method1();
}
interface MyInter2 extends MyInter1{
  public void method2();
}
public class Interface4 implements MyInter2{
  public void method1(){
  	System.out.println("method1 override");
  }
  public void method2(){
  	System.out.println("method2 override");
  }
  public static void main(String[] args){
    Interface4 ob=new Interface4(); 
    ob.method1();
    ob.method2();
    
  }
}