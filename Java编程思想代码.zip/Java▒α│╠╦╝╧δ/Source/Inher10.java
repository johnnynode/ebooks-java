public class Inher10{
  public static void main(String[] args){
    Super ob1=new Sub();
    Sub ob2=(Sub)ob1;
    ob2.hi();
    ob2.bye();
  }
}
