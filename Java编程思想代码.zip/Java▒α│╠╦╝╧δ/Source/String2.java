public class String2{
  public static void main(String[] args){
    String s1=new String("ABCDEFGH");
    System.out.println(s1.charAt(4));
    System.out.println(s1.compareTo("abc"));
    System.out.println(s1.compareToIgnoreCase("abcdefgh"));
    System.out.println(s1.concat("abc"));
    System.out.println(s1.endsWith("FGH"));
    System.out.println(s1.equals("ABCDEFGH"));
    System.out.println(s1.equalsIgnoreCase("abcdefgh"));
  }
}






















