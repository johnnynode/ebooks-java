import java.awt.*;
public class Paint1 extends Frame{
  public Paint1(String title){
    super(title);
  }
  public void paint(Graphics g){
      g.drawLine(10,30,50,50);
      g.drawRect(60,30,50,50);
      g.drawString("Hello!",120,50);
  }  
  public static void main(String[] args){
    Paint1 f=new Paint1("paint");
    f.setSize(200,100);
    f.setVisible(true);
  }
}
