import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
public class Transform1 extends Frame{
  public Transform1(String title){
    super(title);
  }
  public void paint(Graphics g){
  	Graphics2D g2=(Graphics2D)g;
  	
  	g2.translate(100, 100);
    g2.draw(new Line2D.Float(-100, 0, 100, 0));
    g2.draw(new Line2D.Float(0, -100, 0, 100));
    g2.fill(new Ellipse2D.Float(50, 50, 20, 20));
  }  
  public static void main(String[] args){
    Frame f=new Transform1("���� �̵�");
    f.setSize(200, 200);
    f.setVisible(true);
  }
}
