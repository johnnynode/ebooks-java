import java.awt.*;
public class Menu1{
  public static void main(String[] args){
    Frame f=new Frame("Menu");
    MenuBar mb=new MenuBar();
    Menu m_File=new Menu("����");
    Menu m_Edit=new Menu("����");
    Menu m_View=new Menu("����");
    mb.add(m_File);
    mb.add(m_Edit);
    mb.add(m_View);
    f.setMenuBar(mb);
    f.setSize(200,200);    
    f.setVisible(true);
  }
}