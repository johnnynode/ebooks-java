class SumThread extends Thread{
  int from, to;
  long sum;
  SumThread(int from, int to){
  	this.from=from;
  	this.to=to;
  }
  long getSum(){
  	return sum;
  }
  public void run(){
    for(int i=from;i<=to;i++)
      sum+=i;
  }
}
public class Thread3{
  public static void main(String[] args){
     SumThread st=new SumThread(1, 1000);
     st.start();
     System.out.println(st.getSum());
     System.out.println(st.isAlive());
  }
}
