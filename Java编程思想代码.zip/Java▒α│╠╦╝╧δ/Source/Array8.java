public class Array8{
  public static void main(String[] args){
    int[][] a;
    a=new int[3][];
    a[0]=new int[5];
    a[1]=new int[4];
    a[2]=new int[3];
    System.out.println(a.length);
    System.out.println(a[0].length);
    System.out.println(a[1].length);
    System.out.println(a[2].length);
  } 
}