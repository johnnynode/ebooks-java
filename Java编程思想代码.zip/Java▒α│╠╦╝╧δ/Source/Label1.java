import java.awt.*;
public class Label1{
  public static void main(String[] args){
     Frame f=new Frame("Label");
     Label l1=new Label("���̺�1");
     Label l2=new Label("���̺�2",Label.RIGHT);
     Label l3=new Label("",Label.CENTER);
     l3.setText(l1.getText()+l2.getText());
     f.add(l1,"North");
     f.add(l2,"Center");
     f.add(l3,"South");
     f.setSize(200,100);
     f.setVisible(true);
  }
}