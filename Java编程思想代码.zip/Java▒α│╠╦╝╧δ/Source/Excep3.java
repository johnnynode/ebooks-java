public class Excep3{
  void hi(){
  	System.out.println("���̿�~~");
  }
  public static void main(String[] args){
     Excep3 ob=null;
     try{
       ob.hi();
     }catch(NullPointerException ne){
       ob=new Excep3();
     }
     ob.hi();
  }
}