class Outer{
   int a=10;
   class Inner{
     static final int a=100;
     void f(){
       System.out.println(this.a);
       System.out.println(Outer.this.a);	
     }
   }
}
public class Member3{
  public static void main(String[] args){
     Outer out=new Outer();
     Outer.Inner in=out.new Inner();
     in.f();
  }
}
