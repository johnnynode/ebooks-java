import java.awt.*;
import java.net.*;
public class Image2 extends Frame{
  Image[] img;
  Toolkit tkit;
  public Image2(String title){
    super(title);
    tkit=getToolkit();
    img=new Image[2];
    URL url;
    try{
      url=new URL("http://java.sun.com/docs/books/tutorial/figures/2d/2D-1.gif");
      img[0]=tkit.getImage(url);
      url=new URL("http://java.sun.com/docs/books/tutorial/figures/2d/2D-2.gif");
      img[1]=tkit.getImage(url);

      MediaTracker mTracker =new MediaTracker(this);
      mTracker.addImage(img[0],0);
      mTracker.addImage(img[1],1);
      System.out.println("�̹��� �ε���...");
      mTracker.waitForAll();
      if(mTracker.isErrorAny()){
      	System.out.println("�̹��� �ٿ�ε� ����");
        System.exit(1);
      }
      System.out.println("�̹��� �ε� �Ϸ�");
    }catch(Exception e){
      System.out.println(e);	
    }
  }
  public void paint(Graphics g){
  	g.drawImage(img[0],20,30,this);
  	g.drawImage(img[1],20,160,this);
  }
  public static void main(String[] args){
    Frame f=new Image2("�̹��� �׸���");
    f.setSize(450,250);
    f.setVisible(true);
  }
}