import java.io.*;
public class Serialize2{
  public static void main(String[] args) throws Exception{
  	 FileInputStream fis=new FileInputStream("c:\\obj.dat");
     ObjectInputStream ois=new ObjectInputStream(fis);
     Man m;
     m=(Man)ois.readObject();
     ois.close();
     System.out.println(m.�̸�);
     System.out.println(m.����);
     System.out.println(m.Ű);
  }
}
