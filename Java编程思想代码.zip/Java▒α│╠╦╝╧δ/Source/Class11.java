public class Class11{
  void hi(){
  	System.out.println("Hi~~~~");
    this.hello();
  }
  void hello(){
    System.out.println("Hello~~");
  }
  public static void main(String[] args){
     Class11 ob= new Class11();
     ob.hi();
  }
}