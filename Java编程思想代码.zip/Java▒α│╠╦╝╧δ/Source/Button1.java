import java.awt.*;
import java.awt.event.*;
public class Button1 implements ActionListener{
  int count=0;
  Button button=new Button("���ϱ�");
  Label label=new Label("0");
  Frame frame=new Frame("Button");
  public Button1(){
  	button.addActionListener(this);
  	frame.add(button, "Center");
  	frame.add(label,"South");
  	frame.pack();
  	frame.setVisible(true);
  }
  public void actionPerformed(ActionEvent ae){
  	count++;
    label.setText(String.valueOf(count));	
  }
  public static void main(String[] args){
     Button1 but=new Button1();
  }
}