public class Excep8{
  static void go(int size) throws NegativeArraySizeException{
    int[] a=new int[size];
    System.out.println(a.length);
  }
  public static void main(String[] args){
    try{
      go(10);
    }catch(NegativeArraySizeException e){
      System.out.println("�迭�� ũ��� ���");
    }
  } 
}