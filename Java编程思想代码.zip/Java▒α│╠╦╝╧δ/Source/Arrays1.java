import java.util.*;
public class Arrays1{
  public static void main(String[] args){
     int[] a=new int[]{52, 38, 43, 21, 15, 27, 32, 54, 36, 79};
     Arrays.sort(a);
     for(int i=0;i<a.length;i++)
       System.out.print(a[i]+" ");
     System.out.println("\n54�� �ִ� ��ġ:" + Arrays.binarySearch(a, 54));
     System.out.println("41�� �ִ� ��ġ:" + Arrays.binarySearch(a, 41));
  }	
}