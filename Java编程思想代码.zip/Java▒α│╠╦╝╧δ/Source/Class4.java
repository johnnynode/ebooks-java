public class Class4{
  void printInt(int x){
  	System.out.println("����= "+x);
  }  
  public static void main(String[] args){
     Class4 aaa=new Class4();
     aaa.printInt(10);
     System.out.println("�ȳ�~~");
     aaa.printInt(20);
  }
}