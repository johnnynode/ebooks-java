public class Operator2{
  public static void main(String[] args){
      int a=10, b=20;
      a++;
      System.out.println("a= "+a);
      b--;
      System.out.println("b= "+b);
  	}
}
