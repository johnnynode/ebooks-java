class MyThread extends Thread{
   public void run(){
    for(int i=1;i<=10;i++)
      System.out.println(super.getName()+": "+i);
   }
}
public class Thread2{
  public static void main(String[] args){
     MyThread mt=new MyThread();
     mt.start();
  }
}
