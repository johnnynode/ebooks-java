public class Excep5{
  public static void main(String[] args){
     try{
       int[] a=new int[-1];
     }catch(Exception e){
      	System.out.println(e);
     }
  } 
}