public class Object9{
  static void toHello(String s){
  	 s="Hello";
  }	
  public static void main(String[] args){
  	String hi="Hi";
  	toHello(hi);
    System.out.println(hi);
  }
}
