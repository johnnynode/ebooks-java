public class Switch1{
  public static void main(String[] args){
     int n=2;
     switch(n){
       case 0:  System.out.println("000");	
       case 2:  System.out.println("222");	
       case 7:  System.out.println("777");	
       case 9:  System.out.println("999");	
       default: System.out.println("����");		
     } 	 
  }
}