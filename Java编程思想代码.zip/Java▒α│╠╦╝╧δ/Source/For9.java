public class For9{
  public static void main(String[] args){
     for(int a=1;a<=2;a++){
       for(int b=1;b<=3;b++){
         System.out.println("a="+a+" b="+b);
       }
     }  
  }
}
