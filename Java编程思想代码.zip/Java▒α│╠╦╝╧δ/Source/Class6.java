public class Class6{
  void hello(){
  	 System.out.println("�ȳ��ϼ���?");
  }
  public static void main(String[] args){
     Class6 aaa=new Class6();
     aaa.hello();
     aaa.hello();
  }
}