import java.io.*;
public class RAF1{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\raf1.txt");
    RandomAccessFile raf=new RandomAccessFile(f,"rw");
    int a=10;
    double b=12.34;
    String c="abc";
    raf.writeInt(a);
    raf.writeDouble(b);
    raf.writeUTF(c);
    raf.close();
    System.out.println("������ ����������ϴ�.");
  }
}
