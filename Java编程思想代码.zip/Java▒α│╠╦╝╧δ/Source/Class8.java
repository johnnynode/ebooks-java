public class Class8{
  public static void main(String[] args){
     int a;
     System.out.println(a);
  }
}