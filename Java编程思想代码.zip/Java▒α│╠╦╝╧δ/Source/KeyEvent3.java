import java.awt.*;
import java.awt.event.*;
public class KeyEvent3 extends Frame{
  Button man;
  public KeyEvent3(String title){
  	super(title);
  	setLayout(null);
  	this.setSize(200,200);
  	
  	man=new Button("Man");
    man.setBounds(100,100,40,20);
    man.setBackground(Color.BLUE);
    man.setForeground(Color.WHITE);
  	
  	this.add(man);
  	man.addKeyListener(new KeyHandler());
  }
  public static void main(String[] args){
    KeyEvent3 me=new KeyEvent3("Key �̺�Ʈ Ȱ��");
    me.setVisible(true);
  }
  class KeyHandler extends KeyAdapter{
  	public void keyPressed(KeyEvent e){
      String direction=e.getKeyText(e.getKeyCode());
      int x=man.getX();
      int y=man.getY();
      if(direction.equals("Right")) x+=10;
      else if(direction.equals("Left")) x-=10;
      else if(direction.equals("Down")) y+=10;
      else if(direction.equals("Up")) y-=10;
      
      man.setLocation(x,y);
  	}
  }
}