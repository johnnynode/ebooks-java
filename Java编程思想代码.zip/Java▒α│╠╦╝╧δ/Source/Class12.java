public class Class12{
  static int a;
  int b;
  public static void main(String[] args){
     Class12.a=10;
     Class12 ob1= new Class12();
     Class12 ob2= new Class12();
     System.out.println(ob1.a);
     ob1.a=20;
     System.out.println(ob2.a);
     ob2.a=30;
     System.out.println(Class12.a);
  }
}