public class String3{
  public static void main(String[] args){
    String s1=new String("This is a String");
    System.out.println(s1.indexOf('i'));
    System.out.println(s1.indexOf('i',7));
    System.out.println(s1.indexOf("is"));
    System.out.println(s1.indexOf("is", 5));
    System.out.println(s1.lastIndexOf("is"));
  }
}






















