import java.awt.*;
public class Dialog1{
  public static void main(String[] args){
     Frame frm=new Frame("Dialog ����");
     Dialog dlg=new Dialog(frm,"��ȭ����",true);
     Panel p=new Panel();
     p.setLayout(new GridLayout(1,2));
     p.add(new Button("��"));
     p.add(new Button("�ƴϿ�"));
     dlg.add(new Label("�ڹٸ� �����ϼ���?"),"Center");
     dlg.add(p,"South");
     frm.setBounds(100,100,200,100);
     dlg.setBounds(150,200,200,100);
     frm.setVisible(true);
     dlg.setVisible(true);
     System.out.println("����");
  }
}
