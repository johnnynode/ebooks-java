import java.awt.*;
public class Layout1{
  public static void main(String[] args){
     Frame f=new Frame("BorderLayout");
     Button bn=new Button("NORTH");
     Button be=new Button("EAST");
     Button bw=new Button("WEST");
     Button bs=new Button("SOUTH");
     Button bc=new Button("CENTER");
     f.add(bn,BorderLayout.NORTH);
     f.add(be,BorderLayout.EAST);
     f.add(bw,BorderLayout.WEST);
     f.add(bs,BorderLayout.SOUTH);
     f.add(bc,BorderLayout.CENTER);
     f.setSize(170,150);
     f.setVisible(true);
  }
}