class Man{
  int height;
  int age;
}

public class Class1{
  public static void main(String[] args){
     Man man1;
     man1=new Man();
     man1.height=180;
     man1.age=20;
     System.out.println(man1.height);
     System.out.println(man1.age); 	
  }
}