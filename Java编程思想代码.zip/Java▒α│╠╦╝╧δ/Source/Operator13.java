public class Operator13{
  public static void main(String[] args){
     System.out.println("abc" instanceof String);
     System.out.println("abc" instanceof Object);
  }
}