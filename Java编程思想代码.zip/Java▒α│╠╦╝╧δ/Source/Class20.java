class Class20_A{
  private int num;
  void setNum(int a){
  	num=a;
  }	
  int getNum(){
  	return num;
  }	
}
  
public class Class20{
  public static void main(String[] args){
    Class20_A ob=new Class20_A();
    ob.setNum(10);
    System.out.println(ob.getNum());
  }
}