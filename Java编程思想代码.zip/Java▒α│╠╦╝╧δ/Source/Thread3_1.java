public class Thread3_1{
  public static void main(String[] args){
     SumThread st=new SumThread(1, 1000);
     st.start();
     try{
       st.join();
     }catch(InterruptedException ie){}

     System.out.println(st.getSum());
  }
}
