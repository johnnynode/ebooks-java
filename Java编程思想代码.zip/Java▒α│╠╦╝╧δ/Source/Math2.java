public class Math2{
  public static void main(String[] args){
  	System.out.println(Math.ceil(3.4));
  	System.out.println(Math.ceil(-3.4));
  	System.out.println(Math.floor(3.4));
  	System.out.println(Math.floor(-3.4));
  	System.out.println(Math.rint(3.4));
  	System.out.println(Math.rint(-3.4));
  	System.out.println(Math.pow(2, 3));
  	System.out.println(Math.round(3.7));
  	System.out.println(Math.round(-3.7));
  	System.out.println(Math.random());
  	System.out.println(Math.random());
  	
  }
}
















