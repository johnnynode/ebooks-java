class Outer{
   void f(){
     Inner in=new Inner();
     System.out.println(in.a);
   }	
   class Inner{
     int a=100;
   }
}
public class Member2{
  public static void main(String[] args){
     Outer out=new Outer();
     out.f();
  }
}
