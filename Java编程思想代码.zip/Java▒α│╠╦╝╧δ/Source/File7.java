import java.io.*;
public class File7{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\���ĺ�.txt");
    FileInputStream fis=new FileInputStream(f);
    int len=(int)f.length();
    byte[] b=new byte[len];
    fis.read(b);
    fis.close();
    for(int i=0;i<b.length;i++)
       System.out.print((char)b[i]);
  }
}
