public class Object5{
  static void method(int a){     // x1
  	a=20;                     // x2
  }
  public static void main(String[] args){
    int x=10;
    method(x);             // x3
    System.out.println(x);  // x4
  } 
}

