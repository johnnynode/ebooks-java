public class While2{
  public static void main(String[] args){
    int a=2, b;
    while(a<=9){
      b=1;
      while(b<=9){
        System.out.print(" "+a+"*"+b+"="+a*b);
        b++;
      }
      System.out.println();
      a++;
    }
  }
}






















