public class Operator5{
  public static void main(String[] args){
      int a=100;
      System.out.println(a<<1);
      System.out.println(a<<2);
      System.out.println(a>>1);
      System.out.println(a>>2);
      System.out.println(a>>>1);
      System.out.println();
      int b=-100;
      System.out.println(b<<1);
      System.out.println(b<<2);
      System.out.println(b>>1);
      System.out.println(b>>2);
      System.out.println(b>>>1);
   	}
}
