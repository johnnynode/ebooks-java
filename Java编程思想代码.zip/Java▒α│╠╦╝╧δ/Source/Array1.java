public class Array1{
  public static void main(String[] args){
  	int[] a;
  	a=new int[10];
  	System.out.println(a.length);
  }
}