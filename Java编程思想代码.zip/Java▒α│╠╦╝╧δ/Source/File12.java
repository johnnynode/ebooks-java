import java.io.*;
public class File12{
  public static void main(String[] args) throws Exception{
    FileOutputStream fos=new FileOutputStream("c:\\char.txt");
    OutputStreamWriter osw=new OutputStreamWriter(fos);
    BufferedWriter bw=new BufferedWriter(osw);
    bw.write("�ȳ��ϼ���.");
    bw.newLine();
    bw.write("�ݰ����ϴ�.^^");
    bw.newLine();
    bw.close();
    FileInputStream fis=new FileInputStream("c:\\char.txt");
    InputStreamReader isr=new InputStreamReader(fis);
    BufferedReader br=new BufferedReader(isr);
    System.out.println(br.readLine());
    System.out.println(br.readLine());
    isr.close();
  }
}
