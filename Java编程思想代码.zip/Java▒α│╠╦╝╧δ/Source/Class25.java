public class Class25{
  int a;
  String b;
  public static void main(String[] args){
    Class25 ob1=new Class25();
    Class25 ob2=new Class25();
    Class25 ob3=new Class25();
    System.out.println(ob1.a+" "+ob1.b);
    System.out.println(ob2.a+" "+ob2.b);
    System.out.println(ob3.a+" "+ob3.b);
  }
}