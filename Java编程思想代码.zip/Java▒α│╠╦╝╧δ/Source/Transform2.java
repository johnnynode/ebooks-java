import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
public class Transform2 extends Frame implements ActionListener{
  int theta;
  Button clockwise=new Button("�ð� ����");
  Button counterClockwise=new Button("�� �ð� ����");
  Graphics2D g2;
  public Transform2(String title){
    super(title);
    setLayout(new FlowLayout());
    add(clockwise);
    add(counterClockwise);
    clockwise.addActionListener(this);
    counterClockwise.addActionListener(this);
    
  }
  public void actionPerformed(ActionEvent ae){
    if(ae.getSource()==clockwise)
      theta=15;
    else if(ae.getSource()==counterClockwise)
      theta=-15;
    repaint();
  }
  public void paint(Graphics g){
    if(g2==null){
      g2=(Graphics2D)getGraphics();
      g2.translate(150,150);
    } 
    g2.rotate(Math.toRadians(theta));
    g2.draw(new Line2D.Float(-100, 0, 100, 0));
    g2.draw(new Line2D.Float(0, -100, 0, 100));
    g2.fill(new Ellipse2D.Float(50, 50, 20, 20));
  }  
  public static void main(String[] args){
    Frame f=new Transform2("��ǥ�� ȸ��");
    f.setSize(300, 300);
    f.setVisible(true);
  }
}
