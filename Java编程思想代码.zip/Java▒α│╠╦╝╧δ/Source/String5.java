public class String5{
  public static void main(String[] args){
    String s1=new String("This is a String");
    System.out.println(s1.toLowerCase());
    System.out.println(s1.toUpperCase());
    System.out.println(new String("  abc  ").trim());
    System.out.println(String.valueOf(1234));
    System.out.println(String.valueOf(12.345));
  }
}






















