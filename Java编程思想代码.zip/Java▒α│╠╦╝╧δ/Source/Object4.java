public class Object4{
  Object4(){
  	System.out.println("��ü�� ����");
  }
  void hi(){
  	System.out.println("�ȳ�~~~");
  }
  public static void main(String[] args){
    Object4 ob=null;
    if(ob==null)
       ob=new Object4();
    ob.hi();
  }
}