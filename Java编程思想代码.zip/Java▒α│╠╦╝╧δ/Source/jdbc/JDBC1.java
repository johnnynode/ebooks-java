import java.sql.*;
public class JDBC1{
  public static void main(String[] args){
    Connection connect=null;
    Statement st=null;
    ResultSet rset=null;
    try{
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    }catch(ClassNotFoundException ce){
      System.out.println(ce);  
    }
    try{
      connect = DriverManager.getConnection("jdbc:odbc:Test");
      st = connect.createStatement();
      rset= st.executeQuery("Select * from �Ż�����");
      while(rset.next()){
        String ID=rset.getString("�ֹε�Ϲ�ȣ");
        String name= rset.getString("�̸�");
        String address = rset.getString("�ּ�");
        long capital = rset.getLong("�ں���");
         
        System.out.println("�ֹε�Ϲ�ȣ: "+ ID
                          + ", �̸�: " + name 
                          + ", �ּ�: " + address
                          +", �ں���: " + capital);
      }
    }catch(SQLException se){
      System.out.println(se);
    }finally{
      try{
        if(rset!=null)rset.close();
        if(st!=null)st.close();
        if(connect!=null)connect.close();
      }catch(SQLException se){}
    } 
  }
}


