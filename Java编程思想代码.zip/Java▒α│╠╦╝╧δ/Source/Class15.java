public class Class15{
  static int a;
  static void hello(){
  	System.out.println("�ȴ�~~");
  }
  static void setA(int b){
  	a=b;
  	hello();
  }
  void printA(){
  	System.out.println(a);
  	hello();
  }
  public static void main(String[] args){
    Class15.setA(100);
    Class15 ob=new Class15();
    ob.printA();
  }
}