import java.awt.*;
import java.awt.event.*;
public class TextEvent1 extends Frame{
  Label text;
  Label length;
  TextField tf;
  public TextEvent1(String title){
  	super(title);
  	setLayout(new GridLayout(3,1));
  	
  	text=new Label("���ڿ�: ");
    length=new Label("���ڼ�: 0");
    tf=new TextField();
  	
  	add(text);
  	add(length);
  	add(tf);
  	tf.addTextListener(new TextHandler());
  }
  public static void main(String[] args){
    TextEvent1 f=new TextEvent1("�ؽ�Ʈ �̺�Ʈ ó��");
    f.setSize(200,200);
    f.setVisible(true);
  }
  class TextHandler implements TextListener{
  	public void textValueChanged(TextEvent e){
  	  text.setText("���ڿ�: "+tf.getText());
  	  length.setText("���ڼ�: "+tf.getText().length());
  	}
  }
}