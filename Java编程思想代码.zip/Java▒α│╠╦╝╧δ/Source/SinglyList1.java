class Entry{
  Object element;
  Entry next;
  Entry(Object element){
    this.element = element;
    this.next = null;
  }
  Object getElement(){
    return element;
  }
}
public class SinglyList1{
  Entry header=new Entry(null);
  Entry add(Object o){
    Entry newEntry =new Entry(o);
    Entry e=header;
    while(e.next!=null)
      e=e.next;
    e.next = newEntry; 
    return newEntry;
  }
  Entry remove(){
    Entry e=header;
    if(e.next==null)return null;
    while(e.next.next!=null)
      e=e.next;
    Entry temp = e.next;
    e.next = null; 
    return temp;
  }
  public static void main(String[] args){
    SinglyList1 list = new SinglyList1();
    list.add("���");
    list.add("�ٳ���");
    list.add("�ܰ�");
    System.out.println(list.remove().getElement());
    System.out.println(list.remove().getElement());
    System.out.println(list.remove().getElement());
  }
}


