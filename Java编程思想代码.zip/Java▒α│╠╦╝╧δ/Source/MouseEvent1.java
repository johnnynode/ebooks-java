import java.awt.*;
import java.awt.event.*;
public class MouseEvent1 extends Frame{
  Label mouseInfo;
  public MouseEvent1(String title){
  	super(title);

  	mouseInfo=new Label("");
    mouseInfo.setBackground(Color.YELLOW);
  	add(mouseInfo,"North");
  	
  	this.addMouseListener(new MouseHandler());  	
  }
  public static void main(String[] args){
    MouseEvent1 me=new MouseEvent1("Mouse �̺�Ʈ ó��");
    me.setSize(200,200);
    me.setVisible(true);
  }
  class MouseHandler implements MouseListener{
  	public void mouseClicked(MouseEvent e){
  		mouseInfo.setText(mouseInfo.getText()+" Ŭ��");
  	}
    public void mousePressed(MouseEvent e){
  	   if(e.getButton()==e.BUTTON1)
  		  mouseInfo.setText("���� ��ư ����");
       else if(e.getButton()==e.BUTTON2)
  		  mouseInfo.setText("��� ��ư ����");
  	   else if(e.getButton()==e.BUTTON3)
  		  mouseInfo.setText("������ ��ư ����");	  
  	}
  	public void mouseReleased(MouseEvent e){
  		mouseInfo.setText("������");
  	}
  	public void mouseEntered(MouseEvent e){
  		mouseInfo.setText("����");
  	}
  	public void mouseExited(MouseEvent e){
  		mouseInfo.setText("����");
  	}
  }
}