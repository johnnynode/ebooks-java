import java.awt.*;
import java.awt.event.*;

class MyMenuBar extends MenuBar{
  public MyMenuBar(Frame parent){
    parent.setMenuBar(this);
  }
  public void addMenus(String[] menus){
     for(int i=0;i<menus.length;i++)
       add(new Menu(menus[i]));
  }
  public void addMenuItems(int menuNumber,String[] items){
     for(int i=0;i<items.length;i++){
       if(items[i]!=null)
         getMenu(menuNumber).add(new MenuItem(items[i]));
       else getMenu(menuNumber).addSeparator();
     }  
  }
  public void addActionListener(ActionListener al){
    for(int i=0;i<getMenuCount();i++)
      for(int j=0;j< getMenu(i).getItemCount();j++)
        getMenu(i).getItem(j).addActionListener(al);
  }
}
public class MyMenuBarTest implements ActionListener{
  public void actionPerformed(ActionEvent e){
    System.out.println(e.getActionCommand());  
  }
  public static void main(String[] args){
    Frame f=new Frame("MyMenuBar Test");
    MyMenuBar mb=new MyMenuBar(f);
    
    mb.addMenus(new String[]{"����","ã��"});
    
    mb.addMenuItems(0, new String[]{"����","����","����",null,"����"});
    mb.addMenuItems(1, new String[]{"ã��",null,"ã�� �ٲٱ�"});
 
    
    mb.addActionListener(new MyMenuBarTest());
    f.setSize(300,300);
    f.setVisible(true);
  }
}