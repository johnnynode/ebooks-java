public class Array5{
  int a,b;
  public static void main(String[] args){
  	Array5[] arr=new Array5[2];
  	arr[0]=new Array5();
  	arr[1]=new Array5();
  	arr[0].a=10; arr[0].b=20;
  	arr[1].a=30; arr[1].b=40;
  
  	System.out.println(arr[0].a+arr[0].b);
    System.out.println(arr[1].a+arr[1].b);
  }
}