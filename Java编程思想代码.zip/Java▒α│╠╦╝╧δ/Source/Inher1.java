
class Inher1_1{
  int a;	
  void hi(){
  	System.out.println("����~~");
  }
}
public class Inher1 extends Inher1_1{
  public static void main(String[] args){
     Inher1 ob=new Inher1();
     ob.a=10;
     ob.hi();
  }
}