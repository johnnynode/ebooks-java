public class Casting{
  public static void main(String[] args){
      byte a=7;
      int  b=2;
      double c=3.4;
      double d=a/b+c;          // x1
      double e=(double)a/b+c;  // x2
      System.out.println(d);
  	  System.out.println(e);
  	}
}
