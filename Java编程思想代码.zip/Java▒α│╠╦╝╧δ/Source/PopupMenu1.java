import java.awt.*;
public class PopupMenu1{
  public static void main(String[] args){
    Frame f=new Frame("PopupMenu");
    PopupMenu m_Edit=new PopupMenu("����");

    MenuItem mi_Cut=
       new MenuItem("�߶󳻱�");
    MenuItem mi_Copy=
       new MenuItem("����");
    MenuItem mi_Paste=
       new MenuItem("�����ֱ�");
    
    m_Edit.add(mi_Cut);
    m_Edit.add(mi_Copy);
    m_Edit.add(mi_Paste);
        
    f.add(m_Edit);
    f.setSize(200,200);
    f.setVisible(true);
    
    m_Edit.show(f,50,50);
  }
}