import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
public class Swing3 extends JFrame{
  int ox, oy;
  Random rnd = new Random();
  Swing3(String title){
    super(title);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    getContentPane().setBackground(Color.white);
    addMouseListener(new MouseAdapter(){
      public void mousePressed(MouseEvent me){
        ox=me.getX(); oy=me.getY();
      }
    });
    addMouseMotionListener(new MouseMotionAdapter(){
      public void mouseDragged(MouseEvent me){
        int x= me.getX(), y=me.getY();
        Graphics g=getGraphics();
        g.setColor(new Color(rnd.nextInt(256),rnd.nextInt(256),rnd.nextInt(256)));
        g.drawLine(ox, oy, x, y);
        ox=x; oy=y;
      }
    });
  }
  
  public static void main(String[] args) throws Exception{
    JFrame f=new Swing3("����");
    f.setSize(300, 300);
    f.setVisible(true);
  }
}
 

