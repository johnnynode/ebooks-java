import javax.swing.*;

public class Swing1{
  
  public static void main(String[] args) throws Exception{
    JFrame f = new JFrame("����");
    f.setSize(200,200);
    f.setVisible(true);
  }
}


