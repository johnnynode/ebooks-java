import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
public class Swing2{
  public static void main(String[] args) throws Exception{
    JFrame f = new JFrame("����");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container cp=f.getContentPane();
    cp.setLayout(new FlowLayout());

    cp.add(new JButton("��ư"));
    ImageIcon saveIcon = new ImageIcon("images/saveIcon.gif");
    cp.add(new JButton(saveIcon));
    
    JTextField tf = new JTextField("����~~~~~");
    tf.setBorder(new TitledBorder("����"));
    cp.add(tf);
    
    cp.add(new JSlider());
    
    JProgressBar pb = new JProgressBar(JProgressBar.HORIZONTAL);
    pb.setStringPainted(true);
    pb.setValue(50);
    cp.add(pb);
    
    JList list = new JList(new String[]{"�ڹ�","C++"});
    cp.add(list);
    
    JComboBox combo = new JComboBox(new String[]{"�����ϴ�","�ڹ�"});
    cp.add(combo);
    
    f.setSize(200, 200);
    f.setVisible(true);
  }
}
 

