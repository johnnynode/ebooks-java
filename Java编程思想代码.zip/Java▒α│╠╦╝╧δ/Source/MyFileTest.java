import java.awt.*;
import java.awt.event.*;
import java.io.*;
class MyFile{
  private FileDialog fDlg;
  public MyFile(Frame parent){
    fDlg=new FileDialog(parent,"",FileDialog.LOAD); 
  }
  private String getPath(){
    return fDlg.getDirectory()+"\\"+fDlg.getFile();
  }
  public String getData() throws IOException{
    fDlg.setTitle("����");
    fDlg.setMode(FileDialog.LOAD);
    fDlg.setVisible(true);
    BufferedReader br=
            new BufferedReader(new FileReader(getPath()));
    StringBuffer sb=new StringBuffer();
    String aline;
    while((aline=br.readLine())!=null)
      sb.append(aline+'\n');  
    br.close();   
    return sb.toString();   
  }
  public void setData(String data) throws IOException{
    fDlg.setTitle("����");
    fDlg.setMode(FileDialog.SAVE);
    fDlg.setVisible(true);
    BufferedWriter bw=
            new BufferedWriter(new FileWriter(getPath()));  
    bw.write(data);
    bw.close();
  }
}
public class MyFileTest{
  public static void main(String[] args){
    Frame f=new Frame("MyFile Test");
    TextArea ta=new TextArea();
    f.add(ta);
    f.setSize(300,300);
    f.setVisible(true);
    MyFile mf=new MyFile(f);
    try{
      ta.setText(mf.getData());
      mf.setData(ta.getText());
    }catch(IOException ie){}
    
  }
}