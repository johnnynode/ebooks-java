public class For6{
  public static void main(String[] args){
     int a=1;
     for( ;a<=5; ){
        System.out.print(a+" ");
        a++;
     }
  }	
}