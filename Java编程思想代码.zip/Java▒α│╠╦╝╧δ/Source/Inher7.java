class Inher7_1{
  void hello(){
  	System.out.println("���̿�");
  }
}
public class Inher7 extends Inher7_1{
  void hello(String a){
  	System.out.println(a);
  }
  public static void main(String[] args){
    Inher7 ob=new Inher7();
    ob.hello();
    ob.hello("�氡��");
  }
}