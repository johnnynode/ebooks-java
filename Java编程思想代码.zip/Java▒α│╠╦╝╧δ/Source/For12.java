public class For12{
  public static void main(String[] args){
  outer: for(int a=1;a<=3;a++){
          for(int b=1; b<=2;b++){
            if(a<=2)continue outer;
              System.out.println(a+" "+b);
            }
          System.out.println("�ȳ� "+a);
         }
  }
}