import java.awt.*;
import java.awt.event.*;
public class CloseFrameDialog extends Dialog implements ActionListener{
  Button yes=new Button("��");
  Button no=new Button("�ƴϿ�");
  Frame owner;
  Label msgLabel;
  public CloseFrameDialog(Frame owner,String title,String msg){
	super(owner,title, true);
    this.owner=owner;
	msgLabel=new Label(msg,Label.CENTER);
	Panel p=new Panel(); 
    p.setLayout(new GridLayout(1,2));
    p.add(yes);
    p.add(no);
    add(msgLabel,"Center");
    add(p,"South");
    yes.addActionListener(this);
    no.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e){
  	String command=e.getActionCommand();
  	if(command.equals("��")){
  	   owner.dispose();
  	}
  	else if(command.equals("�ƴϿ�")){
  	   this.dispose();	
  	}
  }
  
}
