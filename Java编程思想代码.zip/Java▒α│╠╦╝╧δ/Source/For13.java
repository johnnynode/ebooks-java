public class For13{
  public static void main(String[] args){
     for(int a=2;a<=9;a++){
       for(int b=1; b<=9;b++){
            System.out.print(a+"*"+b+"="+a*b+" ");
       }
       System.out.println();  
     }
  }
}