class PrintThread extends Thread{
  char ch;
  public PrintThread(char ch){
  	this.ch=ch;
  }
  void printCh10(){
    for(int i=1;i<=10;i++)
  	   System.out.print(ch);
  }
  public void run(){
  	for(int i=1;i<=10;i++){
  	  printCh10();
  	  System.out.println();
    }
  }
}
public class Synchronization1{
  public static void main(String[] args) throws Exception{
     PrintThread pt=new PrintThread('A');
     pt.start();
  }
}
