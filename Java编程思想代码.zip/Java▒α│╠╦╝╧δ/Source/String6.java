public class String6{
  public static void main(String[] args){
    StringBuffer sb=new StringBuffer();
    sb.append("ABC");
    sb.append(123);
    sb.append(true);
    System.out.println(sb);
    sb.delete(1, 3);
    System.out.println(sb);
    sb.deleteCharAt(4);
    System.out.println(sb);
    sb.insert(5, "@@");
    System.out.println(sb);
    sb.insert(6, 7.89);
    System.out.println(sb);
  }
}






















