public class Integral2{
  public static void main(String[] args){
   
    int   i4=0xABCDL;   
    System.out.println(i1);
    System.out.println(i2);
    System.out.println(i3);
    System.out.println(i4);
  }
}

