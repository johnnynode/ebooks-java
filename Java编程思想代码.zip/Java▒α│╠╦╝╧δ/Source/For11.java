public class For11{
  public static void main(String[] args){
     for(int a=1;a<=3;a++){
       for(int b=1; b<=2;b++){
         if(a<=2)continue;
            System.out.println(a+" "+b);
       }
       System.out.println("�ȳ� "+a);
     }
  }
}