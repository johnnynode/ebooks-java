public class For10{
  public static void main(String[] args){
     for(int a=1;a<=2;a++){
       for(int b=1; b<=3;b++){
       	 for(int c=1; c<=2;c++){
           System.out.println("a= "+a+" b= "+b+" c= "+c);
         }
       }
     }      
  }
}