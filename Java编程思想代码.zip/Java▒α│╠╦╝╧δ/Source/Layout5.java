import java.awt.*;
public class Layout5{
  public static void main(String[] args){
     Frame f=new Frame("Layout ����");
     f.setLayout(null);
     Button b1=new Button("Layout��");
     Button b2=new Button("null��");
     b1.setBounds(20,50,100,40);
     b2.setBounds(50,100,100,40);
     f.add(b1);
     f.add(b2);
     f.setSize(200,160);
     f.setVisible(true);
  }
}