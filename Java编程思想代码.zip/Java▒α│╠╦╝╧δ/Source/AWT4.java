import java.awt.*;
public class AWT4{
  public static void main(String[] args) throws Exception{
     Frame f=new Frame("�����̳�");
     Button b=new Button("������");
     f.add(b);
     f.setSize(200,100);
     f.setVisible(true);
  }
}