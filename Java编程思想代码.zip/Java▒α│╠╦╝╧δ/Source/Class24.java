public class Class24{
  static boolean isSame(int a, int b){
  	return a==b;
  }	
  static boolean isSame(double a, double b){
    return a==b;
  }
  public static void main(String[] args){
    System.out.println(isSame(1, 2));
    System.out.println(isSame(1.2, 1.2));
  }
}