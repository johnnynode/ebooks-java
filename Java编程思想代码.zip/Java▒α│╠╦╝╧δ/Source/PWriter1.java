import java.io.*;
public class PWriter1{
  public static void main(String[] args) throws IOException{
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw=new PrintWriter(System.out, true);
    String s;
    pw.println("���ڸ� �Է��� ������.");
    while(!(s=br.readLine()).equals(""))
      pw.println(s);
    br.close();
    pw.close();
  }
}
