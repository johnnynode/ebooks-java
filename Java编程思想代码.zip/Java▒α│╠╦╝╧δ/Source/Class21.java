class Class21_A{
  public int num;
  public void hi(){
  	System.out.println("�ȳ�~~");
  }
}
  
public class Class21{
  public static void main(String[] args){
    Class21_A ob=new Class21_A();
    ob.num=10;
    ob.hi();
    System.out.println(ob.num);
  }
}