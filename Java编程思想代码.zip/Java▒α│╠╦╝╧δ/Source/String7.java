public class String7{
  public static void main(String[] args){
    StringBuffer sb=new StringBuffer("ABCDEFG");
    sb.replace(0, 3,"abc");
    System.out.println(sb);
    sb.reverse();
    System.out.println(sb);
  }
}






















