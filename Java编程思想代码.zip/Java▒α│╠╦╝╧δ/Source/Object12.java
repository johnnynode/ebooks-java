
public class Object12{
  private String key;
  Object12(String key){
    this.key=key;	
  }
  String getKey(){
    return key;	
  }
  void setKey(String key){
    this.key=key;	
  }
  public static void main(String[] args){
    Object12 ob=new Object12("hello");
    String mkey=ob.getKey();
    System.out.println(mkey);
    ob.setKey("�ҷ�");
    System.out.println(ob.getKey());
  }
}
