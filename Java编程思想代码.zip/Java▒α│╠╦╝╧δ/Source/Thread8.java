class NewLine extends Thread{
  public void run(){
  	for(int i=1;i<=10;i++){
  	  System.out.println();
  	  try{
  	    sleep(1000);
  	  }catch(InterruptedException ie){} 
 	}
  }
}
public class Thread8 extends Thread{
  public void run(){
  	for(int i=1;i<=100;i++){
  	  System.out.print(i);
  	  try{
  	   sleep(100);
  	  }catch(InterruptedException ie){} 
  	}
  }
  public static void main(String[] args){
    Thread8 t=new Thread8();
    NewLine n=new NewLine();
    t.start();
    n.start();
  }
}
