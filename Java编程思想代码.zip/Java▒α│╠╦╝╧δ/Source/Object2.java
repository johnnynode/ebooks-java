public class Object2{
  Object2(){
  	System.out.println("��ü�� ����");
  }
  void hi(){
  	System.out.println("�ȳ�~~~");
  }
  public static void main(String[] args){
    Object2 ob;
    ob.hi();
  }
}