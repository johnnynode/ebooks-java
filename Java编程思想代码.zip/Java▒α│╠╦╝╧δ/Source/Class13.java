public class Class13{
  static int return123(){
    return 123;
  }  
  public static void main(String[] args){
     System.out.println(Class13.return123());
     Class13 ob= new Class13();
     System.out.println(ob.return123());
  }
}