public class Thread6 extends Thread{
  public void run(){
  	for(int i=1;i<=10;i++)
  	System.out.println(getName()+": "+i);
  }
  public static void main(String[] args){
    Thread6 t1=new Thread6();
    Thread6 t2=new Thread6();
    t1.setPriority(Thread.MIN_PRIORITY);
    t2.setPriority(Thread.MAX_PRIORITY);
    t1.start();
    t2.start();
  } 
}
