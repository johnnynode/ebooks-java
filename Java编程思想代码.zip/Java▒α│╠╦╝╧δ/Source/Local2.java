public class Local2{
  void f(final int a, int b){
  	int c=30;
  	final int d=40;
  	class Inner{
      void hi(){
      	System.out.println(a);
     // System.out.println(b);
     // System.out.println(c);
  	    System.out.println(d);
  	  }	
  	}
  	Inner in=new Inner();
  	in.hi();
  }
  public static void main(String[] args){
     Local2 local=new Local2();
     local.f(10,20);
  }
}
