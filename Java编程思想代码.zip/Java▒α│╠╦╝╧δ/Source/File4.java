import java.io.*;
public class File4{
  public static void main(String[] args) throws Exception{
    FileOutputStream fos=new FileOutputStream("c:\\���ĺ�.txt");
    for(int i='A';i<='Z';i++)
      fos.write(i);
    fos.close();  
  }
}
