import java.awt.*;
public class Layout4{
  public static void main(String[] args){
     Frame f=new Frame("Layout ����");
     f.setLayout(new FlowLayout());
     f.add(new Button("Layout"));
     f.add(new Button("������"));
     f.add(new Button("setLayout()"));
     f.add(new Button("����"));
     f.pack();
     f.setVisible(true);
  }
}