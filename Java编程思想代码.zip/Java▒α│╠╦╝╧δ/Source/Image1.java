import java.awt.*;
import java.net.*;
public class Image1 extends Frame{
  Image img;
  Toolkit tkit;
  public Image1(String title){
    super(title);
    tkit=getToolkit();
    try{
      URL url=new URL("http://java.sun.com/images/v4_java_logo.gif");
      img=tkit.getImage(url);
      tkit.prepareImage(img,-1,-1,this);
    }catch(MalformedURLException e){
      System.out.println("URL�� �ùٸ��� �ʽ��ϴ�.");
    }
  }
  public void paint(Graphics g){
     g.drawImage(img,80,80,this);
  }
  public static void main(String[] args){
    Frame f=new Image1("�̹��� �׸���");
    f.setSize(200,200);
    f.setVisible(true);
  }
}