public class Class9{
  int  a;
  int  b=100;
  String c;
  String d="����~~~~";
  public static void main(String[] args){
     Class9 ob= new Class9();
     System.out.println(ob.a);
     System.out.println(ob.b);
     System.out.println(ob.c);
     System.out.println(ob.d);
  }
}
