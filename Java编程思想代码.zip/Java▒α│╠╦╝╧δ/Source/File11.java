import java.io.*;
public class File11{
  public static void main(String[] args) throws Exception{
    FileOutputStream fos=new FileOutputStream("c:\\char.txt");
    OutputStreamWriter osw=new OutputStreamWriter(fos);
    osw.write('��');
    osw.write('��');
    osw.close();
    FileInputStream fis=new FileInputStream("c:\\char.txt");
    InputStreamReader isr=new InputStreamReader(fis);
    System.out.println((char)isr.read());
    System.out.println((char)isr.read());
    isr.close();
  }
}
