import java.awt.*;
import java.awt.event.*;
public class AdjustmentEvent1 extends Frame implements AdjustmentListener{
  Scrollbar sb;
  Label label;
  public AdjustmentEvent1(String title){
  	super(title);
  	label =new Label("Thinking Java",label.CENTER);
  	sb=new Scrollbar(Scrollbar.HORIZONTAL,10,1,1,300);
  	add(label,"Center");
  	add(sb,"South");
  	sb.addAdjustmentListener(this);
    
  }
  public void adjustmentValueChanged(AdjustmentEvent e){
  	  Font font=new Font("����",1,sb.getValue());
  	  label.setFont(font);
  }
    
  
  public static void main(String[] args) throws Exception{
    AdjustmentEvent1 f=new AdjustmentEvent1("���� �̺�Ʈ ó��");
    f.setSize(300,300);
    f.setVisible(true);
  }
}