public class For14{
  public static void main(String[] args){
outer: for(int a=2;a<=100;a++){
         for(int b=2; b<=a-1;b++){
           if(a%b==0)continue outer;   
         }
         System.out.print(a+" ");  
       }
  }
}