public class Array11{
  public static void main(String[] args){
    String[][] s=new String[2][];
    s[0]=new String[2];
    s[1]=new String[2];
    s[0][0]=new String("������");
    s[0][1]=new String("ABC");
    s[1][0]=new String("�ѱ���");
    s[1][1]=new String("��Ű");
    System.out.println(s[0][0]);
    System.out.println(s[1][1]);
  }   
}