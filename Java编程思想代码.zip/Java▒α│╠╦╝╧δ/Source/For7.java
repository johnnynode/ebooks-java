public class For7{
  public static void main(String[] args){
     for(int a=1,b=1;(a+b)<=10;a++, b++){
        System.out.print((a+b)+" ");
     }
  }	
}