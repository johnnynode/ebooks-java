import java.io.*;
public class RAF2{
  public static void main(String[] args) throws Exception{
    File f=new File("c:\\raf1.txt");
    RandomAccessFile raf=new RandomAccessFile(f,"r");
    System.out.println("���Ϸκ��� �н��ϴ�.");
    System.out.println(raf.readInt());
    System.out.println(raf.readDouble());
    System.out.println(raf.readUTF());
    raf.close();
  }
}
