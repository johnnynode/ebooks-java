interface MyInter1{
  public void method1();
}
interface MyInter2{
  public void method2();
}
public class Interface2 implements MyInter1, MyInter2{
  public void method1(){
  	System.out.println("method1 override");
  }
  public void method2(){
  	System.out.println("method2 override");
  }
  public static void main(String[] args){
    Interface2 ob=new Interface2(); 
    ob.method1();
    ob.method2();
  }
}