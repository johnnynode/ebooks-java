import java.awt.*;
public class Layout2{
  public static void main(String[] args){
     Frame f=new Frame("FlowLayout");
     Panel p=new Panel();
     p.add(new Button("��ư��"));    
     p.add(new Button("��"));
     p.add(new Button("��"));
     p.add(new Button("��"));
     p.add(new Button("��..."));
     f.add(p);
     f.pack();
     f.setVisible(true);
  }
}