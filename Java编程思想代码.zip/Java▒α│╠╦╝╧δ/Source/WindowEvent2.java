import java.awt.*;
import java.awt.event.*;
public class WindowEvent2 extends Frame implements WindowListener{
  public WindowEvent2(){
  	setTitle("������ �ݱ� �̺�Ʈ ó��");
    addWindowListener(this);
  }
  public void windowClosing(WindowEvent e){
    CloseFrameDialog d=
       new CloseFrameDialog(this,"�ݱ�","�����ðڽ��ϱ�?");
    d.setSize(200,100);
    d.setVisible(true);
  }
  public void windowClosed(WindowEvent e){}
  public void windowDeactivated(WindowEvent e){}
  public void windowActivated(WindowEvent e){}
  public void windowIconified(WindowEvent e){}
  public void windowDeiconified(WindowEvent e){}
  public void windowOpened(WindowEvent e){}
		
  public static void main(String[] args){
    WindowEvent2 me=new WindowEvent2();
    me.setSize(200,200);
    me.setVisible(true);
  }
}