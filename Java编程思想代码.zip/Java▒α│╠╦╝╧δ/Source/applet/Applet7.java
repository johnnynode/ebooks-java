import java.awt.*;
import java.applet.*;
import java.net.*;
import java.awt.event.*;
public class Applet7 extends Applet implements MouseListener{
  Image image1, image2; 
  URL url;
  String target;
  AppletContext context;
  public void init(){
    target=getParameter("target");
    try{
      url=new URL(getParameter("url"));
    }catch(Exception e){}
    image1=getImage(getDocumentBase(),getParameter("image1"));
    image2=getImage(getDocumentBase(),getParameter("image2"));
    context=getAppletContext();
    addMouseListener(this);
    
  }
  public void paint(Graphics g){
    g.drawImage(image1,0,0,getWidth(),getHeight(),this); 
  }
  public void mouseEntered(MouseEvent me){
    getGraphics().drawImage(image2,0,0,getWidth(),getHeight(),null);
    context.showStatus("�׸��� ��������.");
  }
  public void mouseExited(MouseEvent me){
    getGraphics().drawImage(image1,0,0,getWidth(),getHeight(),null); 
    context.showStatus("������ �����ϱ�.");
  }
  public void mouseClicked(MouseEvent me){
    context.showDocument(url, target);
    context.showStatus("��â�� ����?");
  }
  public void mousePressed(MouseEvent me){}
  public void mouseReleased(MouseEvent me){} 
}
