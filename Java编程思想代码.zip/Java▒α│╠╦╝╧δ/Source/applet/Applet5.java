import java.awt.*;
import java.applet.*;
public class Applet5 extends Applet implements Runnable{
  Image background;
  String text;
  boolean loop=true;
  int delay; 
  public void init(){
    background=getImage(getCodeBase(), getParameter("background"));
    text=getParameter("text");
    delay=Integer.parseInt(getParameter("delay")); 
  }
  public void start(){
    Thread t;
    t=new Thread(this);
    t.start();
  }
  public void stop(){
    loop=false;
  }
  public void run(){
    int x=0;
    Graphics g=getGraphics();
    Image buffer=createImage(getWidth(),getHeight());
    Graphics g2=buffer.getGraphics();
    while(loop){
      g2.drawImage(background,0,0, getWidth(), getHeight(),this);
      g2.drawString(text,x,50);
      g.drawImage(buffer,0,0,this);
      x+=2;
      if(x>=getWidth())x=0;
      try{
        Thread.sleep(delay);
      }catch(Exception e){} 
    }
  }
}
