import java.awt.*;
import java.applet.*;
import java.awt.event.*;
public class Applet8_Controller extends Applet implements MouseMotionListener{
  Applet8 applet8;
  public void init(){
    addMouseMotionListener(this);
    setBackground(Color.red);
  }
  public void mouseMoved(MouseEvent me){  
    if(applet8==null)
       applet8=(Applet8)getAppletContext().getApplet("applet8");
    applet8.moveLabel(me.getX(), me.getY());
  }
  public void mouseDragged(MouseEvent me){}
}
