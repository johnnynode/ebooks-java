import java.awt.*;
import java.applet.*;
public class Applet4 extends Applet{
  AudioClip music;
  public void init(){
    music=getAudioClip(getCodeBase(),"sounds/spacemusic.au");
  }
  public void start(){
    music.loop();  
  }
  public void stop(){
    music.stop();
  }
}
