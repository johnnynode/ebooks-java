import java.awt.*;
import java.applet.*;
import java.awt.event.*;
public class Applet10 extends Applet implements Runnable, ActionListener{
  private Image imgBall, buff;
  private Scrollbar vCon;
  private Thread ballThread;
  private double S, V, T;
  private static final double G=9.8;
  private Graphics2D ga, gb;
  private int width,height;
  private Button b=new Button("�߻�");
  private Paint skyPaint=new GradientPaint(0,0, Color.white, 0, -500, Color.blue, false);
  public void init(){
    width=getWidth();
    height=getHeight();
    imgBall=getImage(getDocumentBase(),"images/Red_Ball.gif");
    getToolkit().prepareImage(imgBall,-1,-1,this);
    buff=createImage(width,height);
    vCon=new Scrollbar(Scrollbar.HORIZONTAL,50,1,0,100);
    setLayout(new BorderLayout());
    Panel p=new Panel();
    p.setLayout(new BorderLayout());
    p.add(vCon,"North");
    p.add(b,"Center");
    add(p,"South");
    b.addActionListener(this);
  }
  public void paint(Graphics g){
    if(ga==null)
      ga=(Graphics2D)getGraphics();
    if(gb==null){
      gb=(Graphics2D)buff.getGraphics();
      gb.translate(width/2, height/2);
    }
    drawScreen();
  }
  public void actionPerformed(ActionEvent ae){
    if(ballThread==null || !ballThread.isAlive()){
      S=0; V=vCon.getValue(); T=0;
      ballThread=new Thread(this);
      ballThread.start();
    }  
  }
  public void drawScreen(){
    gb.setPaint(new Color(200,200,50));
    gb.fillRect(-width/2, 0,width , height/2);
    gb.setPaint(skyPaint);
    gb.fillRect(-width/2, -height/2,width , height/2);
    gb.drawImage(imgBall,0,-(int)S,null);
    gb.drawString("T= "+String.valueOf(T),-100,50);
    gb.drawString("S= "+String.valueOf(S),-100,65);
    ga.drawImage(buff,0,0, this);
  }
  public void run(){
    while(true){
      T+=0.1;
      S=V*T-0.5*G*T*T;
      drawScreen();
      if((int)S<=0)break;
      try{
        Thread.sleep(100);
      }catch(Exception e){}
    }
  }
}
