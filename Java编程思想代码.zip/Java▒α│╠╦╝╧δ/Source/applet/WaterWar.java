import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.util.Random;
class WaterObject extends Thread{
  static final int LEFT=0;
  static final int RIGHT=1;
  static final int UP=2;
  static final int DOWN=3;
  Image img;
  int speed;
  int x, y;
  int direction;
  WaterObject(){}
  WaterObject(Image img, int x, int y, int direction){
    this.img=img; this.x=x;this.y=y;
    this.direction=direction;
  }
  void setSpeed(int speed){
    this.speed=speed; 
  }
  int getSpeed(){
    return speed;
  }
  void setDirection(int direct){
    this.direction=direct;
  }
  void draw(Graphics g, ImageObserver observer){
    g.drawImage(img, x, y, observer);
  }
  void move(){ 
    switch(direction){
      case LEFT: x-=speed; break;
      case RIGHT: x+=speed; break;
      case UP: y-=speed; break;
      case DOWN: y+=speed; break;
    }
  }
}
class WaterBomb extends WaterObject{
  Image imgExp;
  WaterUnit owner;
  boolean explosion=false;
  boolean loop=true;
  WaterBomb(Image img, Image imgExp, int x, int y, int direct, WaterUnit owner){
    super(img, x, y, direct);
    this.imgExp=imgExp;
    this.owner=owner;
    setSpeed(3);
  }
  boolean intersects(WaterUnit ob){
    Rectangle2D rect=new Rectangle(x, y, img.getWidth(null), img.getHeight(null));
    int obW=ob.img.getWidth(null), obH=ob.img.getHeight(null);
    return rect.intersects(ob.x+4, ob.y+5, obW-10, obH-10);
  }
  void draw(Graphics g, ImageObserver observer){
    if(explosion)
      g.drawImage(imgExp, x-10, y-10, observer); 
    else super.draw(g, observer);
  }
  void check(){
    WaterUnit[] target=owner.getEnemys();
    for(int i=0;i<target.length;i++)
      if(intersects(target[i])){
        explosion=true;
        if(owner instanceof WarShip){
           WarShip ship=(WarShip)owner;
           ship.addKillCount();
        }  
        loop=false;
        target[i].damage(1);
      }
  }
  public void run(){
    while(loop){
      if(direction==DOWN && y>=290)loop=false;
      else if(direction==UP && y<100)loop=false;
      check();
      move();
      try{sleep(100);}catch(Exception e){}
    }
  }
}
class WaterUnit extends WaterObject{
  int life=1;
  Image imgLeft;
  Image imgBomb, imgExp;
  WaterBomb[] bomb;
  WaterUnit[] enemy;
  int bombX, bombY;
  int bCount=1;
  WaterUnit(){}
  WaterUnit(Image img, Image imgLeft, int x, int y, int direct, Image imgBomb, Image imgExp){
    super(img, x, y, direct);
    this.imgLeft=imgLeft;
    this.imgBomb=imgBomb;
    this.imgExp=imgExp;
    bomb=new WaterBomb[50];
    bombX=23; bombY=15;
  }
  void damage(int dam){
    life-=dam;
  }
  void setBombCount(int n){
    bCount=n; 
  }
  int getBombCount(){
    return bCount; 
  }
  void setLife(int life){
    this.life=life; 
  }
  int getLife(){
    return life; 
  }
  void setEnemys(WaterUnit[] enemy){
     this.enemy=enemy;
  }
  WaterUnit[] getEnemys(){
    return enemy; 
  }
  void fireBomb(int direct){
    for(int i=0;i<bCount;i++)
      if(bomb[i]==null || !bomb[i].isAlive()){
        bomb[i]=new WaterBomb(imgBomb, imgExp, x+bombX,y+bombY,direct,this);
        bomb[i].start();
        break;
      }
  }
  void draw(Graphics g, ImageObserver observer){
    if(direction==RIGHT)
      g.drawImage(img, x, y, observer);
    else if(direction==LEFT)
      g.drawImage(imgLeft, x, y, observer);  
    for(int i=0;i<bCount;i++)
      if(bomb[i]!=null && bomb[i].isAlive())
        bomb[i].draw(g, observer);
  }
}
class WarShip extends WaterUnit{
  boolean keyLeft=false;
  boolean keyRight=false;
  int kills=0;
  WarShip(Image img, Image imgLeft, int x, int y, int direct, Image imgBomb, Image imgExp){
    super(img, imgLeft, x, y, direct, imgBomb, imgExp);
    setBombCount(3); setLife(10);setSpeed(5);
  }
  void addKillCount(){
    kills++; 
  }
  void setKey(int keyCode, boolean pressed){
    if(keyCode==KeyEvent.VK_LEFT)
       keyLeft=pressed;
    if(keyCode==KeyEvent.VK_RIGHT)
       keyRight=pressed;
    if((keyCode==KeyEvent.VK_DOWN || keyCode==KeyEvent.VK_SPACE) && pressed)
       fireBomb(DOWN);
  }
  void drawScore(Graphics2D g){
      g.setPaint(Color.blue);
      g.drawString("Life:  "+String.valueOf(getLife()), 10, 15);
      g.setPaint(Color.red);
      g.drawString("Kills:  "+String.valueOf(kills), 10, 25);
      g.setPaint(Color.green);
      g.drawString("Bombs:  "+String.valueOf(getBombCount()), 10, 35);
  }
  public void run(){
    while(true){
      if(keyLeft){ direction=LEFT; move(); }
      if(keyRight){ direction=RIGHT; move(); }
      try{sleep(70);}catch(Exception e){}
    }
  }
}
class Submarine extends WaterUnit{
  int[] firePoint=new int[50];
  static Random rnd=new Random();
  Submarine(Image img, Image imgLeft, int x, int y, int direct, Image imgBomb, Image imgExp){ 
    super(img, imgLeft, x, y, direct, imgBomb, imgExp);
    randomPosition(); setBombCount(5); setSpeed(5);
  }
  public void randomPosition(){
    y=rnd.nextInt(120)+130;
    if(direction==RIGHT)
      x=-rnd.nextInt(200)-50;
    else
      x=rnd.nextInt(300)+300;
    for(int i=0; i<getBombCount(); i++){
      firePoint[i]=rnd.nextInt(290);
    }
  }
  public void move(){
    for(int i=0; i<getBombCount(); i++){
      if(x<=firePoint[i] && x+speed>firePoint[i]){
        fireBomb(UP);
        break;
      }
    }
    if(direction==RIGHT && x>310){
      direction=LEFT;
      randomPosition();  
    }
    else if( direction==LEFT && x < -80){
      direction=RIGHT;
      randomPosition();
    }
    super.move();
  }
  public void run(){
    while(true){
      if(getLife()<=0){setLife(1);randomPosition();}
      move();
      try{sleep(200);}catch(Exception e){}
    }
  }
}

public class WaterWar extends Applet implements KeyListener, Runnable{
  Image buff, imgLand;
  Canvas screen;
  Graphics2D gs, gb;
  WarShip ship;
  Submarine[] submarine=new Submarine[10];
  boolean running=false;
  Button bStart;
  Thread  game;
  public void init(){
    prepareResource();
    setBackground(Color.yellow);
    initScreen();
    add(screen);
    bStart=new Button("���� ����");
    add(bStart);
    bStart.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ae){
        screen.requestFocus();
        if(running==true)return;
        running=true;
        game.start();
        ship.start();
        for(int i=0;i<submarine.length;i++)
          submarine[i].start();
      }
    });
  }
  public void prepareResource(){
    imgLand=getImage(getCodeBase(),"images/land.gif");
    Image imgShipRight=getImage(getCodeBase(),"images/ship1.gif");
    Image imgShipLeft=getImage(getCodeBase(),"images/ship2.gif");
    Image imgDepthBomb=getImage(getCodeBase(),"images/depthbomb.gif");
    Image imgSubRight=getImage(getCodeBase(),"images/submarine1.gif");
    Image imgSubLeft=getImage(getCodeBase(),"images/submarine2.gif");
    Image imgExp=getImage(getCodeBase(),"images/pung.gif");
    Image imgTorpedo=getImage(getCodeBase(),"images/torpedo.gif");
    
    MediaTracker mt=new MediaTracker(this);
    mt.addImage(imgLand,0);
    mt.addImage(imgShipRight,1);
    mt.addImage(imgShipLeft,2);
    mt.addImage(imgDepthBomb,3);
    mt.addImage(imgSubRight,4);
    mt.addImage(imgSubLeft,5);
    mt.addImage(imgExp,6);
    mt.addImage(imgTorpedo,7);
    try{
      mt.waitForAll();
    }catch(Exception e){}
    buff=createImage(300,300);

    gb=(Graphics2D)buff.getGraphics();
    ship=new WarShip(imgShipRight, imgShipLeft,100,70,1, imgDepthBomb, imgExp);
    WarShip[] temp=new WarShip[]{ship};
    for(int i=0;i<submarine.length;i++){
      submarine[i]=new Submarine(imgSubRight, imgSubLeft,0,0,i%2,imgTorpedo,imgExp);
      submarine[i].setEnemys(temp);
    }  
    ship.setEnemys(submarine);
    game=new Thread(this);
  }
  public void run(){
    while(true){
      drawScreen();
      try{ Thread.sleep(100);}catch(Exception e){}
    }  
  }
  private void initScreen(){
    screen=new Canvas(){
       public void paint(Graphics g){
         if(gs==null)
           gs=(Graphics2D)screen.getGraphics();
         drawScreen();
       }
    };
    screen.setSize(300,300);
    screen.addKeyListener(this);
  }
  private synchronized void drawScreen(){
    gb.clearRect(0, 0, 300, 300);
    gb.drawImage(imgLand,0,270,screen);
    drawSky();
    for(int i=0;i<submarine.length;i++)
      submarine[i].draw(gb, screen);
    ship.draw(gb, screen);
    ship.drawScore(gb);
    drawWater();
    
    gs.drawImage(buff, 0,0, screen);
  }
  private void drawSky(){
    Paint old=gb.getPaint();
    GradientPaint grad; 
    grad=new GradientPaint(0,0, new Color(200,200,255), 0, 100, Color.white, false);
    gb.setPaint(grad);
    gb.fillRect(0,0,300,100);
    gb.setPaint(old);
  }
  private void drawWater(){
    Composite old=gb.getComposite();
    AlphaComposite alpha;
    alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f);
    gb.setPaint(Color.blue);
    gb.setComposite(alpha);
    gb.fillRect(0,100,300,200);
    gb.setComposite(old);
  }
  public void keyPressed(KeyEvent ke){
    ship.setKey(ke.getKeyCode(), true);
  }
  public void keyReleased(KeyEvent ke){
    ship.setKey(ke.getKeyCode(), false);
  }
  public void keyTyped(KeyEvent ke){}
}
