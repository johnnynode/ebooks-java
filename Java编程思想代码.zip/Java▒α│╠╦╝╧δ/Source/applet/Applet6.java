import java.awt.*;
import java.applet.*;
public class Applet6 extends Applet{
  public void paint(Graphics g){
    g.drawString("���������� ���ø� �޼ҵ� ȣ��",50,50);
  }
  public void setRed(){
    setBackground(new Color(255, 0, 0));
  }
  public void setGreen(){
    setBackground(new Color(0, 255, 0));
  }
  public void setBlue(){
    setBackground(new Color(0, 0, 255));
  }
}
