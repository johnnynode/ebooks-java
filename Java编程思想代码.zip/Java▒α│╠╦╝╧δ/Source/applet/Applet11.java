import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.awt.geom.*;
public class Applet11 extends Applet implements MouseListener, MouseMotionListener{
  Rectangle2D[] p=new Rectangle2D.Double[3];
  Image buff;
  Graphics2D ga, gb;
  double dx, dy;
  int selection=-1;
  public void init(){
    buff=createImage(getWidth(),getHeight());
    gb=(Graphics2D)buff.getGraphics();
    p[0]=new Rectangle2D.Double(150, 50, 5, 5);
    p[1]=new Rectangle2D.Double(60, 200, 5, 5);
    p[2]=new Rectangle2D.Double(240, 200, 5, 5);
    addMouseMotionListener(this);
    addMouseListener(this); 
  }
  public void paint(Graphics g){
    if(ga==null)
      ga=(Graphics2D)getGraphics();
    drawScreen();
  }
  public void drawScreen(){
    gb.clearRect(0, 0, getWidth(), getHeight());
    GeneralPath triangle =new GeneralPath();
    triangle.moveTo((float)p[0].getX(), (float)p[0].getY());
    triangle.lineTo((float)p[1].getX(), (float)p[1].getY());
    triangle.lineTo((float)p[2].getX(), (float)p[2].getY());
    triangle.closePath();
    gb.setPaint(new Color(204, 205, 255));
    gb.fill(triangle);
    gb.setPaint(new Color(0, 0, 0));
    gb.draw(triangle);
    gb.setPaint(Color.red);
 
    for(int i=0;i<p.length;i++)
      gb.fill(p[i]);
    
    ga.drawImage(buff, 0, 0, this);
  }
  public void mousePressed(MouseEvent me){
    int mx=me.getX(), my=me.getY();
    for(int i=0;i<p.length;i++)
      if(p[i].contains(mx, my)){
        dx=mx-(int)p[i].getX();
        dy=my-(int)p[i].getY();
        selection=i;
        break;
      }
  }
  public void mouseDragged(MouseEvent me){
    if(selection>=0 && selection <=p.length){
      int mx=me.getX(), my=me.getY();
      p[selection].setFrame(mx-dx, my-dy, 5, 5);
      drawScreen();
    }
  }
  public void mouseReleased(MouseEvent me){
    selection=-1;
  }
  public void mouseMoved(MouseEvent me){}
  public void mouseEntered(MouseEvent me){}
  public void mouseExited(MouseEvent me){}
  public void mouseClicked(MouseEvent me){}
}
