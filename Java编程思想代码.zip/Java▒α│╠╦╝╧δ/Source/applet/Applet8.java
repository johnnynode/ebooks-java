import java.awt.*;
import java.applet.*;
public class Applet8 extends Applet{
  private Label label;
  public void init(){
    setBackground(Color.yellow);
    label=new Label("�ȳ�");
    add(label);
  }
  public void moveLabel(int x, int y){
    label.setLocation(x, y);
  }
}
