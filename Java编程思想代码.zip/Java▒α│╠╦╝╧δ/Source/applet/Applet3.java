import java.awt.*;
import java.applet.*;
public class Applet3 extends Applet{
  Image img1, img2, img3;
  public void init(){
    img1=getImage(getDocumentBase(),"images/back1.gif");
    img2=getImage(getDocumentBase(),"images/back2.gif");
    img3=getImage(getDocumentBase(),"images/back3.gif");
  }
  public void paint(Graphics g){
    g.drawImage(img1, 0,50,this);
    g.drawImage(img2, 100,50,this);
    g.drawImage(img3, 200,50,this);
  }
}
