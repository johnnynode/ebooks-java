import java.awt.*;
public class ScrollPane1{
  public static void main(String[] args){
    Frame f=new Frame("ScrollPane");
    ScrollPane sp=new ScrollPane(1);
    Panel p=new Panel();
    p.setLayout(new GridLayout(10,2));
    p.setBackground(Color.BLUE);
    p.setForeground(Color.WHITE);
    sp.setBounds(10,30,180,160);
    f.setLayout(null);
    f.setSize(200,200);

    for(int i=1;i<=10;i++){
      p.add(new Label(i+"��° ���̺�"));
      p.add(new Button(i+"��° ��ư"));
    }

    sp.add(p);
    f.add(sp);
    f.setVisible(true);
  }
}