import java.awt.*;
import java.awt.event.*;
public class DBuffering1 extends Frame implements ActionListener{
  Button b1= new Button("�ٷ� �׸���");
  Button b2= new Button("���� ����ϱ�");
  public DBuffering1(String title){
    super(title);
    setLayout(new FlowLayout());
    add(b1);
    add(b2);
    b1.addActionListener(this);
    b2.addActionListener(this);
  }
  private void drawLines(Graphics g, Color color){
    g.setColor(color);
    for(int i=0;i<getHeight();i++){
      g.drawLine(0,i,getWidth(),i); 
    }
  }
  private void drawOnFrame(){
    Graphics g=getGraphics();
    g.clearRect(0,0,getWidth(),getHeight());
    drawLines(g,Color.red);
  }
  private void drawOnBuffer(){
    Image buffer=createImage(getWidth(),getHeight());
    Graphics g=buffer.getGraphics();
    drawLines(g,Color.blue);
    getGraphics().drawImage(buffer,0,0,this);
  }
  public void actionPerformed(ActionEvent ae){
    if(ae.getSource()==b1)
      drawOnFrame();
    else if(ae.getSource()==b2)
      drawOnBuffer();  
  }
  public static void main(String[] args){
    Frame f=new DBuffering1("���� ���۸�");
    f.setSize(300, 300);
    f.setVisible(true);
  }
}
