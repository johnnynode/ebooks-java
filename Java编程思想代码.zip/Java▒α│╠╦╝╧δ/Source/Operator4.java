public class Operator4{
  public static void main(String[] args){
      int a=10, b=10;
      int c=--a;
      int d=b--;
      System.out.println("a= "+a);
      System.out.println("b= "+b);
      System.out.println("c= "+c);
      System.out.println("d= "+d);
  }
}
