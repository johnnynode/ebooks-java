import java.awt.*;
public class AWT5{
  public static void main(String[] args){
     Frame f=new Frame("Panel�� Window");
     Button b1=new Button("Ȯ��");
     Button b2=new Button("���");
     Panel p=new Panel();
     p.setBackground(new Color(200,200,0));
     p.add(b1);
     p.add(b2);
     f.add(p);
     f.setSize(200,100);
     f.setVisible(true);
  }
}