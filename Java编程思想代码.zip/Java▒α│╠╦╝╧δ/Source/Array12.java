public class Array12{
  public static void main(String[] args){
    int[][][] a=new int[2][][];
    a[0]=new int[2][];
    a[1]=new int[3][];
    a[0][0]=new int[4];
    a[0][1]=new int[4];
    a[1][0]=new int[3];
    a[1][1]=new int[3];
    a[1][2]=new int[3];
    a[0][0][0]=10;
    a[1][1][1]=20;
    System.out.println(a.length);
    System.out.println(a[1].length);
    System.out.println(a[1][2].length);
    System.out.println(a[1][1][1]);
  }
}