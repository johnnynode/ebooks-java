public class Synchronization2{
  public static void main(String[] args){
     PrintThread pt1=new PrintThread('A');
     PrintThread pt2=new PrintThread('B');
     pt1.start();
     pt2.start();
  }
}
