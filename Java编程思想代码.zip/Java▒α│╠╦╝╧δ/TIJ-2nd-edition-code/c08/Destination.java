//: c08:Destination.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
public interface Destination {
  String readLabel();
} ///:~